/* @ds-bundle: {"format":3,"namespace":"DesignSystem_a4aafe","components":[{"name":"CategoryCard","sourcePath":"components/commerce/CategoryCard.jsx"},{"name":"ProductCard","sourcePath":"components/commerce/ProductCard.jsx"},{"name":"RewardPerk","sourcePath":"components/commerce/RewardPerk.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Icon","sourcePath":"components/icons/Icon.jsx"},{"name":"HeroBanner","sourcePath":"components/marketing/HeroBanner.jsx"},{"name":"PromoTile","sourcePath":"components/marketing/PromoTile.jsx"},{"name":"DuskLogo","sourcePath":"components/navigation/DuskLogo.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Header","sourcePath":"components/navigation/Header.jsx"},{"name":"Marquee","sourcePath":"components/navigation/Marquee.jsx"}],"sourceHashes":{"components/commerce/CategoryCard.jsx":"b6989a533dcd","components/commerce/ProductCard.jsx":"e26f11241a96","components/commerce/RewardPerk.jsx":"c7eb577b059e","components/core/Badge.jsx":"8628a4603e46","components/core/Button.jsx":"3b7472dac016","components/core/IconButton.jsx":"c543c803340a","components/core/Input.jsx":"5e2f0a82199c","components/icons/Icon.jsx":"45fda2cb9e1b","components/icons/icon-data.js":"e2041e27fee4","components/marketing/HeroBanner.jsx":"1c0f349b1773","components/marketing/PromoTile.jsx":"12105eac0272","components/navigation/DuskLogo.jsx":"cead93cad0ed","components/navigation/Footer.jsx":"ca960ca31a3c","components/navigation/Header.jsx":"3784315a1c5d","components/navigation/Marquee.jsx":"8ec7d2b48f95","web-flips/tweaks-panel.jsx":"6591467622ed"},"inlinedExternals":[],"unexposedExports":[{"name":"iconData","sourcePath":"components/icons/icon-data.js"}]} */

(() => {

const __ds_ns = (window.DesignSystem_a4aafe = window.DesignSystem_a4aafe || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/commerce/CategoryCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk CategoryCard — a shop-by-category tile: a photo-led image with a
 * centred label and a "Shop Now" link beneath. Used in the category rail
 * (Candles · Electrical Diffusers · Bath & Body · Gift Sets).
 */
function CategoryCard({
  image,
  label = 'Candles',
  cta = 'Shop Now',
  href = '#',
  ratio = '1 / 1',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      textDecoration: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: ratio,
      background: 'var(--color-surface-plinth)',
      overflow: 'hidden'
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block',
      transition: 'transform 400ms ease'
    },
    onMouseEnter: e => {
      e.currentTarget.style.transform = 'scale(1.04)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--fs-body)',
      letterSpacing: 'var(--ls-ui)',
      color: 'var(--dusk-ink)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-regular)',
      fontSize: 'var(--fs-small)',
      color: 'var(--text-secondary)',
      textDecoration: 'underline',
      textUnderlineOffset: 3
    }
  }, cta)));
}
Object.assign(__ds_scope, { CategoryCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/CategoryCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk Badge — the small pill stamped on product imagery and tiles.
 * Promo flashes ("30% Off", "3 for 2", "Last Chance") are amber; sale
 * flashes are Tokyo red; editorial tags ("Fan Favourite", "Promotion")
 * are a clean white pill with a hairline.
 */
function Badge({
  children,
  tone = 'promo',
  // 'promo' | 'sale' | 'new' | 'neutral' | 'hero'
  style,
  ...rest
}) {
  const tones = {
    promo: {
      background: 'var(--badge-promo-bg)',
      color: 'var(--badge-promo-text)',
      boxShadow: 'none'
    },
    sale: {
      background: 'var(--color-sale)',
      color: 'var(--dusk-white)',
      boxShadow: 'none'
    },
    new: {
      background: 'var(--dusk-ink)',
      color: 'var(--dusk-white)',
      boxShadow: 'none'
    },
    neutral: {
      background: 'var(--dusk-white)',
      color: 'var(--text-body)',
      boxShadow: 'var(--ring-inset)'
    },
    hero: {
      background: 'var(--color-hero)',
      color: 'var(--dusk-white)',
      boxShadow: 'none'
    }
  };
  const t = tones[tone] || tones.promo;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      background: t.background,
      color: t.color,
      boxShadow: t.boxShadow,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--fs-label)',
      lineHeight: 1.1,
      letterSpacing: 'var(--ls-ui)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk Button — the square, confident call-to-action used across every
 * web-flip ("Shop Now", "Join Now"). Sharp corners (radius 0), Lexend
 * Medium, tight tracking. Three fills and two sizes.
 */
function Button({
  children,
  variant = 'primary',
  // 'primary' | 'inverse' | 'sale'
  size = 'default',
  // 'default' | 'small'
  iconRight,
  // optional React node (e.g. an <Icon/>)
  iconLeft,
  fullWidth = false,
  disabled = false,
  as = 'button',
  style,
  ...rest
}) {
  const sizes = {
    default: {
      padding: '15px 24px',
      fontSize: 'var(--fs-small)',
      height: 48,
      gap: 8
    },
    small: {
      padding: '10px 16px',
      fontSize: 'var(--fs-label)',
      height: 35,
      gap: 6
    }
  };
  const variants = {
    primary: {
      background: 'var(--action-fill)',
      color: 'var(--action-on-fill)',
      border: 'none'
    },
    inverse: {
      background: 'var(--action-fill-inverse)',
      color: 'var(--action-on-inverse)',
      border: 'none'
    },
    sale: {
      background: 'var(--color-sale)',
      color: 'var(--dusk-white)',
      border: 'none'
    }
  };
  const s = sizes[size] || sizes.default;
  const v = variants[variant] || variants.primary;
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    disabled: Tag === 'button' ? disabled : undefined,
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : 'auto',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      minHeight: s.height,
      padding: s.padding,
      border: v.border,
      borderRadius: 'var(--radius-none)',
      background: v.background,
      color: v.color,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      fontSize: s.fontSize,
      lineHeight: 1,
      letterSpacing: 'var(--ls-ui)',
      textDecoration: 'none',
      whiteSpace: 'nowrap',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'background var(--transition), opacity var(--transition), transform var(--transition)',
      boxSizing: 'border-box',
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.985)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk IconButton — a circular, hairline-bordered control. Used for
 * wishlist hearts on product imagery, and (borderless) for the header
 * account / wishlist / cart actions.
 */
function IconButton({
  children,
  // an <Icon/> (or any node)
  size = 32,
  variant = 'outline',
  // 'outline' | 'ghost' | 'solid'
  ariaLabel,
  style,
  ...rest
}) {
  const variants = {
    outline: {
      background: 'var(--dusk-white)',
      boxShadow: 'var(--ring-inset)',
      color: 'var(--text-body)'
    },
    ghost: {
      background: 'transparent',
      boxShadow: 'none',
      color: 'var(--text-body)'
    },
    solid: {
      background: 'var(--action-fill)',
      boxShadow: 'none',
      color: 'var(--action-on-fill)'
    }
  };
  const v = variants[variant] || variants.outline;
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": ariaLabel,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      padding: 0,
      border: 'none',
      borderRadius: 'var(--radius-pill)',
      background: v.background,
      boxShadow: v.boxShadow,
      color: v.color,
      cursor: 'pointer',
      transition: 'background var(--transition), color var(--transition), transform var(--transition)',
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.transform = 'scale(1.06)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk Input — square text field used in newsletter sign-up and forms.
 * Hairline border, Lexend, no corner radius. Supports an optional label
 * and a trailing submit affordance via `suffix`.
 */
function Input({
  label,
  id,
  type = 'text',
  placeholder,
  suffix,
  // optional node pinned to the right (e.g. a submit arrow)
  style,
  containerStyle,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      width: '100%',
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      background: 'var(--dusk-white)',
      border: '1px solid var(--surface-border)',
      borderRadius: 'var(--radius-none)'
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: type,
    placeholder: placeholder,
    style: {
      flex: 1,
      minWidth: 0,
      padding: '13px 16px',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-regular)',
      fontSize: 'var(--fs-small)',
      color: 'var(--text-body)',
      ...style
    }
  }, rest)), suffix));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/icons/icon-data.js
try { (() => {
// Generated by fig_materialize (moduleFormat: 'icon-data') — 33 icon(s)
// as { viewBox, body } SVG-markup entries. Render via the sibling Icon.jsx
// (<Icon name="ButtonSocialFacebook" />), or consume the path data directly.
// NOTE: exported as a NAMED const (not default) — the DS bundler drops
// default-exported object literals from plain .js modules.
const iconData = {
  "ButtonSocialFacebook": {
    viewBox: "0 0 40 40",
    body: "<path d=\"M 3.299 18 L 3.273 9.818 L 0 9.818 L 0 6.545 L 3.273 6.545 L 3.273 4.5 C 3.273 1.463 5.153 0 7.862 0 C 9.16 0 10.275 0.097 10.6 0.14 L 10.6 3.313 L 8.721 3.314 C 7.248 3.314 6.963 4.014 6.963 5.041 L 6.963 6.545 L 11.25 6.545 L 9.614 9.818 L 6.963 9.818 L 6.963 18 L 3.299 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 6 3)\"/><path d=\"M 3.299 18 L 2.299 18.003 L 2.302 19 L 3.299 19 L 3.299 18 Z M 3.273 9.818 L 4.273 9.815 L 4.27 8.818 L 3.273 8.818 L 3.273 9.818 Z M 0 9.818 L -1 9.818 L -1 10.818 L 0 10.818 L 0 9.818 Z M 0 6.545 L 0 5.545 L -1 5.545 L -1 6.545 L 0 6.545 Z M 3.273 6.545 L 3.273 7.545 L 4.273 7.545 L 4.273 6.545 L 3.273 6.545 Z M 10.6 0.14 L 11.6 0.14 L 11.6 -0.736 L 10.731 -0.852 L 10.6 0.14 Z M 10.6 3.313 L 10.6 4.313 L 11.6 4.313 L 11.6 3.313 L 10.6 3.313 Z M 8.721 3.314 L 8.721 4.314 L 8.722 4.314 L 8.721 3.314 Z M 6.963 6.545 L 5.963 6.545 L 5.963 7.545 L 6.963 7.545 L 6.963 6.545 Z M 11.25 6.545 L 12.144 6.993 L 12.868 5.545 L 11.25 5.545 L 11.25 6.545 Z M 9.614 9.818 L 9.614 10.818 L 10.232 10.818 L 10.508 10.265 L 9.614 9.818 Z M 6.963 9.818 L 6.963 8.818 L 5.963 8.818 L 5.963 9.818 L 6.963 9.818 Z M 6.963 18 L 6.963 19 L 7.963 19 L 7.963 18 L 6.963 18 Z M 3.299 18 L 4.299 17.997 L 4.273 9.815 L 3.273 9.818 L 2.273 9.821 L 2.299 18.003 L 3.299 18 Z M 3.273 9.818 L 3.273 8.818 L 0 8.818 L 0 9.818 L 0 10.818 L 3.273 10.818 L 3.273 9.818 Z M 0 9.818 L 1 9.818 L 1 6.545 L 0 6.545 L -1 6.545 L -1 9.818 L 0 9.818 Z M 0 6.545 L 0 7.545 L 3.273 7.545 L 3.273 6.545 L 3.273 5.545 L 0 5.545 L 0 6.545 Z M 3.273 6.545 L 4.273 6.545 L 4.273 4.5 L 3.273 4.5 L 2.273 4.5 L 2.273 6.545 L 3.273 6.545 Z M 3.273 4.5 L 4.273 4.5 C 4.273 3.195 4.67 2.362 5.229 1.847 C 5.802 1.319 6.679 1 7.862 1 L 7.862 0 L 7.862 -1 C 6.336 -1 4.919 -0.587 3.874 0.376 C 2.816 1.351 2.273 2.769 2.273 4.5 L 3.273 4.5 Z M 7.862 0 L 7.862 1 C 9.122 1 10.193 1.095 10.468 1.131 L 10.6 0.14 L 10.731 -0.852 C 10.357 -0.901 9.197 -1 7.862 -1 L 7.862 0 Z M 10.6 0.14 L 9.6 0.14 L 9.6 3.313 L 10.6 3.313 L 11.6 3.313 L 11.6 0.14 L 10.6 0.14 Z M 10.6 3.313 L 10.599 2.313 L 8.721 2.314 L 8.721 3.314 L 8.722 4.314 L 10.6 4.313 L 10.6 3.313 Z M 8.721 3.314 L 8.721 2.314 C 7.851 2.314 7.054 2.52 6.524 3.148 C 6.027 3.739 5.963 4.485 5.963 5.041 L 6.963 5.041 L 7.963 5.041 C 7.963 4.571 8.04 4.453 8.054 4.437 C 8.057 4.434 8.061 4.429 8.072 4.422 C 8.084 4.414 8.109 4.4 8.154 4.384 C 8.251 4.35 8.426 4.314 8.721 4.314 L 8.721 3.314 Z M 6.963 5.041 L 5.963 5.041 L 5.963 6.545 L 6.963 6.545 L 7.963 6.545 L 7.963 5.041 L 6.963 5.041 Z M 6.963 6.545 L 6.963 7.545 L 11.25 7.545 L 11.25 6.545 L 11.25 5.545 L 6.963 5.545 L 6.963 6.545 Z M 11.25 6.545 L 10.356 6.098 L 8.719 9.371 L 9.614 9.818 L 10.508 10.265 L 12.144 6.993 L 11.25 6.545 Z M 9.614 9.818 L 9.614 8.818 L 6.963 8.818 L 6.963 9.818 L 6.963 10.818 L 9.614 10.818 L 9.614 9.818 Z M 6.963 9.818 L 5.963 9.818 L 5.963 18 L 6.963 18 L 7.963 18 L 7.963 9.818 L 6.963 9.818 Z M 6.963 18 L 6.963 17 L 3.299 17 L 3.299 18 L 3.299 19 L 6.963 19 L 6.963 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 6 3)\"/>"
  },
  "ButtonSocialInstagram": {
    viewBox: "0 0 40 40",
    body: "<path d=\"M 9 1.622 C 11.403 1.622 11.688 1.631 12.637 1.674 C 13.514 1.714 13.991 1.861 14.308 1.984 C 14.728 2.147 15.028 2.342 15.343 2.657 C 15.658 2.972 15.853 3.272 16.016 3.692 C 16.139 4.009 16.286 4.486 16.326 5.363 C 16.369 6.312 16.378 6.597 16.378 9 C 16.378 11.403 16.369 11.688 16.326 12.637 C 16.286 13.514 16.139 13.991 16.016 14.308 C 15.853 14.728 15.658 15.028 15.343 15.343 C 15.028 15.658 14.728 15.853 14.308 16.016 C 13.991 16.139 13.514 16.286 12.637 16.326 C 11.688 16.369 11.403 16.378 9 16.378 C 6.597 16.378 6.312 16.369 5.363 16.326 C 4.486 16.286 4.009 16.139 3.692 16.016 C 3.272 15.853 2.972 15.658 2.657 15.343 C 2.342 15.028 2.147 14.728 1.984 14.308 C 1.861 13.991 1.714 13.514 1.674 12.637 C 1.631 11.688 1.622 11.403 1.622 9 C 1.622 6.597 1.631 6.312 1.674 5.363 C 1.714 4.486 1.861 4.009 1.984 3.692 C 2.147 3.272 2.342 2.972 2.657 2.657 C 2.972 2.342 3.272 2.147 3.692 1.984 C 4.009 1.861 4.486 1.714 5.363 1.674 C 6.312 1.631 6.597 1.622 9 1.622 Z M 9 0 C 6.556 0 6.249 0.01 5.289 0.054 C 4.331 0.098 3.677 0.25 3.105 0.473 C 2.513 0.703 2.011 1.01 1.511 1.511 C 1.01 2.011 0.702 2.513 0.472 3.105 C 0.25 3.677 0.098 4.331 0.054 5.289 C 0.01 6.249 0 6.556 0 9 C 0 11.444 0.01 11.751 0.054 12.711 C 0.098 13.669 0.25 14.323 0.472 14.895 C 0.702 15.487 1.01 15.989 1.511 16.489 C 2.011 16.99 2.513 17.298 3.105 17.528 C 3.677 17.75 4.331 17.902 5.289 17.946 C 6.249 17.99 6.556 18 9 18 C 11.444 18 11.751 17.99 12.711 17.946 C 13.669 17.902 14.323 17.75 14.895 17.528 C 15.487 17.298 15.989 16.99 16.489 16.489 C 16.99 15.989 17.297 15.487 17.527 14.895 C 17.75 14.323 17.902 13.669 17.946 12.711 C 17.99 11.751 18 11.444 18 9 C 18 6.556 17.99 6.249 17.946 5.289 C 17.902 4.331 17.75 3.677 17.527 3.105 C 17.297 2.513 16.99 2.011 16.489 1.511 C 15.989 1.01 15.487 0.703 14.895 0.473 C 14.323 0.25 13.669 0.098 12.711 0.054 C 11.751 0.01 11.444 0 9 0 Z M 9 4.378 C 6.448 4.378 4.378 6.448 4.378 9 C 4.378 11.552 6.448 13.622 9 13.622 C 11.552 13.622 13.622 11.552 13.622 9 C 13.622 6.448 11.552 4.378 9 4.378 Z M 9 12 C 7.343 12 6 10.657 6 9 C 6 7.343 7.343 6 9 6 C 10.657 6 12 7.343 12 9 C 12 10.657 10.657 12 9 12 Z M 14.884 4.196 C 14.884 4.792 14.401 5.276 13.804 5.276 C 13.208 5.276 12.724 4.792 12.724 4.196 C 12.724 3.599 13.208 3.116 13.804 3.116 C 14.401 3.116 14.884 3.599 14.884 4.196 Z\" fill=\"rgb(0,0,0)\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 3 3)\"/><path d=\"M 12.637 1.674 L 12.682 0.675 L 12.682 0.675 L 12.637 1.674 Z M 14.308 1.984 L 14.67 1.052 L 14.67 1.052 L 14.308 1.984 Z M 16.016 3.692 L 15.084 4.054 L 15.084 4.054 L 16.016 3.692 Z M 16.326 5.363 L 17.325 5.318 L 17.325 5.318 L 16.326 5.363 Z M 16.326 12.637 L 17.325 12.682 L 17.325 12.682 L 16.326 12.637 Z M 16.016 14.308 L 15.084 13.946 L 15.084 13.946 L 16.016 14.308 Z M 14.308 16.016 L 13.946 15.084 L 13.946 15.084 L 14.308 16.016 Z M 12.637 16.326 L 12.682 17.325 L 12.682 17.325 L 12.637 16.326 Z M 5.363 16.326 L 5.318 17.325 L 5.318 17.325 L 5.363 16.326 Z M 3.692 16.016 L 4.054 15.084 L 4.054 15.084 L 3.692 16.016 Z M 1.984 14.308 L 2.916 13.946 L 2.916 13.946 L 1.984 14.308 Z M 1.674 12.637 L 0.675 12.682 L 0.675 12.682 L 1.674 12.637 Z M 1.674 5.363 L 0.675 5.318 L 0.675 5.318 L 1.674 5.363 Z M 1.984 3.692 L 2.916 4.054 L 2.916 4.054 L 1.984 3.692 Z M 3.692 1.984 L 3.33 1.052 L 3.33 1.052 L 3.692 1.984 Z M 5.363 1.674 L 5.318 0.675 L 5.318 0.675 L 5.363 1.674 Z M 5.289 0.054 L 5.244 -0.945 L 5.244 -0.945 L 5.289 0.054 Z M 3.105 0.473 L 3.467 1.405 L 3.467 1.405 L 3.105 0.473 Z M 0.472 3.105 L 1.405 3.467 L 1.405 3.467 L 0.472 3.105 Z M 0.054 5.289 L -0.945 5.244 L -0.945 5.244 L 0.054 5.289 Z M 0.054 12.711 L -0.945 12.756 L -0.945 12.756 L 0.054 12.711 Z M 0.472 14.895 L -0.46 15.258 L -0.46 15.258 L 0.472 14.895 Z M 3.105 17.528 L 3.467 16.595 L 3.467 16.595 L 3.105 17.528 Z M 5.289 17.946 L 5.244 18.945 L 5.244 18.945 L 5.289 17.946 Z M 12.711 17.946 L 12.756 18.945 L 12.756 18.945 L 12.711 17.946 Z M 14.895 17.528 L 14.533 16.595 L 14.533 16.595 L 14.895 17.528 Z M 17.527 14.895 L 16.595 14.533 L 16.595 14.533 L 17.527 14.895 Z M 17.946 12.711 L 18.945 12.756 L 18.945 12.756 L 17.946 12.711 Z M 17.946 5.289 L 18.945 5.244 L 18.945 5.244 L 17.946 5.289 Z M 17.527 3.105 L 16.595 3.467 L 16.595 3.467 L 17.527 3.105 Z M 14.895 0.473 L 14.533 1.405 L 14.533 1.405 L 14.895 0.473 Z M 12.711 0.054 L 12.756 -0.945 L 12.756 -0.945 L 12.711 0.054 Z M 9 1.622 L 9 2.622 C 11.399 2.622 11.665 2.631 12.591 2.673 L 12.637 1.674 L 12.682 0.675 C 11.71 0.631 11.407 0.622 9 0.622 L 9 1.622 Z M 12.637 1.674 L 12.591 2.673 C 13.358 2.708 13.728 2.832 13.946 2.916 L 14.308 1.984 L 14.67 1.052 C 14.253 0.89 13.67 0.72 12.682 0.675 L 12.637 1.674 Z M 14.308 1.984 L 13.946 2.916 C 14.238 3.03 14.42 3.149 14.636 3.364 L 15.343 2.657 L 16.05 1.95 C 15.636 1.536 15.218 1.265 14.67 1.052 L 14.308 1.984 Z M 15.343 2.657 L 14.636 3.364 C 14.851 3.58 14.97 3.762 15.084 4.054 L 16.016 3.692 L 16.948 3.33 C 16.735 2.782 16.464 2.364 16.05 1.95 L 15.343 2.657 Z M 16.016 3.692 L 15.084 4.054 C 15.168 4.272 15.292 4.642 15.327 5.409 L 16.326 5.363 L 17.325 5.318 C 17.28 4.33 17.11 3.747 16.948 3.33 L 16.016 3.692 Z M 16.326 5.363 L 15.327 5.409 C 15.369 6.335 15.378 6.601 15.378 9 L 16.378 9 L 17.378 9 C 17.378 6.593 17.369 6.29 17.325 5.318 L 16.326 5.363 Z M 16.378 9 L 15.378 9 C 15.378 11.399 15.369 11.665 15.327 12.591 L 16.326 12.637 L 17.325 12.682 C 17.369 11.71 17.378 11.407 17.378 9 L 16.378 9 Z M 16.326 12.637 L 15.327 12.591 C 15.292 13.358 15.168 13.728 15.084 13.946 L 16.016 14.308 L 16.948 14.67 C 17.11 14.253 17.28 13.67 17.325 12.682 L 16.326 12.637 Z M 16.016 14.308 L 15.084 13.946 C 14.97 14.238 14.851 14.42 14.636 14.636 L 15.343 15.343 L 16.05 16.05 C 16.464 15.636 16.735 15.218 16.948 14.67 L 16.016 14.308 Z M 15.343 15.343 L 14.636 14.636 C 14.42 14.851 14.238 14.97 13.946 15.084 L 14.308 16.016 L 14.67 16.948 C 15.218 16.735 15.636 16.464 16.05 16.05 L 15.343 15.343 Z M 14.308 16.016 L 13.946 15.084 C 13.728 15.168 13.358 15.292 12.591 15.327 L 12.637 16.326 L 12.682 17.325 C 13.67 17.28 14.253 17.11 14.67 16.948 L 14.308 16.016 Z M 12.637 16.326 L 12.591 15.327 C 11.665 15.369 11.399 15.378 9 15.378 L 9 16.378 L 9 17.378 C 11.408 17.378 11.71 17.369 12.682 17.325 L 12.637 16.326 Z M 9 16.378 L 9 15.378 C 6.601 15.378 6.335 15.369 5.409 15.327 L 5.363 16.326 L 5.318 17.325 C 6.29 17.369 6.592 17.378 9 17.378 L 9 16.378 Z M 5.363 16.326 L 5.409 15.327 C 4.642 15.292 4.272 15.168 4.054 15.084 L 3.692 16.016 L 3.33 16.948 C 3.747 17.11 4.33 17.28 5.318 17.325 L 5.363 16.326 Z M 3.692 16.016 L 4.054 15.084 C 3.762 14.97 3.58 14.851 3.364 14.636 L 2.657 15.343 L 1.95 16.05 C 2.364 16.464 2.782 16.735 3.33 16.948 L 3.692 16.016 Z M 2.657 15.343 L 3.364 14.636 C 3.149 14.42 3.03 14.238 2.916 13.946 L 1.984 14.308 L 1.052 14.67 C 1.265 15.218 1.536 15.636 1.95 16.05 L 2.657 15.343 Z M 1.984 14.308 L 2.916 13.946 C 2.832 13.728 2.708 13.358 2.673 12.591 L 1.674 12.637 L 0.675 12.682 C 0.72 13.67 0.89 14.253 1.052 14.67 L 1.984 14.308 Z M 1.674 12.637 L 2.673 12.591 C 2.631 11.665 2.622 11.399 2.622 9 L 1.622 9 L 0.622 9 C 0.622 11.407 0.631 11.71 0.675 12.682 L 1.674 12.637 Z M 1.622 9 L 2.622 9 C 2.622 6.601 2.631 6.335 2.673 5.409 L 1.674 5.363 L 0.675 5.318 C 0.631 6.29 0.622 6.593 0.622 9 L 1.622 9 Z M 1.674 5.363 L 2.673 5.409 C 2.708 4.642 2.832 4.272 2.916 4.054 L 1.984 3.692 L 1.052 3.33 C 0.89 3.747 0.72 4.33 0.675 5.318 L 1.674 5.363 Z M 1.984 3.692 L 2.916 4.054 C 3.03 3.762 3.149 3.58 3.364 3.364 L 2.657 2.657 L 1.95 1.95 C 1.536 2.364 1.265 2.782 1.052 3.33 L 1.984 3.692 Z M 2.657 2.657 L 3.364 3.364 C 3.58 3.149 3.762 3.03 4.054 2.916 L 3.692 1.984 L 3.33 1.052 C 2.782 1.265 2.364 1.536 1.95 1.95 L 2.657 2.657 Z M 3.692 1.984 L 4.054 2.916 C 4.272 2.832 4.642 2.708 5.409 2.673 L 5.363 1.674 L 5.318 0.675 C 4.33 0.72 3.747 0.89 3.33 1.052 L 3.692 1.984 Z M 5.363 1.674 L 5.409 2.673 C 6.335 2.631 6.601 2.622 9 2.622 L 9 1.622 L 9 0.622 C 6.593 0.622 6.29 0.631 5.318 0.675 L 5.363 1.674 Z M 9 0 L 9 -1 C 6.551 -1 6.227 -0.99 5.244 -0.945 L 5.289 0.054 L 5.335 1.053 C 6.272 1.01 6.561 1 9 1 L 9 0 Z M 5.289 0.054 L 5.244 -0.945 C 4.191 -0.897 3.428 -0.726 2.742 -0.46 L 3.105 0.473 L 3.467 1.405 C 3.926 1.226 4.472 1.093 5.335 1.053 L 5.289 0.054 Z M 3.105 0.473 L 2.742 -0.46 C 2.031 -0.183 1.409 0.198 0.803 0.803 L 1.511 1.511 L 2.218 2.218 C 2.613 1.822 2.995 1.588 3.467 1.405 L 3.105 0.473 Z M 1.511 1.511 L 0.803 0.803 C 0.198 1.409 -0.183 2.031 -0.46 2.742 L 0.472 3.105 L 1.405 3.467 C 1.588 2.995 1.822 2.613 2.218 2.218 L 1.511 1.511 Z M 0.472 3.105 L -0.46 2.742 C -0.726 3.428 -0.897 4.191 -0.945 5.244 L 0.054 5.289 L 1.053 5.335 C 1.092 4.472 1.226 3.926 1.405 3.467 L 0.472 3.105 Z M 0.054 5.289 L -0.945 5.244 C -0.99 6.227 -1 6.551 -1 9 L 0 9 L 1 9 C 1 6.561 1.01 6.272 1.053 5.335 L 0.054 5.289 Z M 0 9 L -1 9 C -1 11.449 -0.99 11.774 -0.945 12.756 L 0.054 12.711 L 1.053 12.665 C 1.01 11.728 1 11.439 1 9 L 0 9 Z M 0.054 12.711 L -0.945 12.756 C -0.897 13.809 -0.726 14.572 -0.46 15.258 L 0.472 14.895 L 1.405 14.533 C 1.226 14.074 1.092 13.528 1.053 12.665 L 0.054 12.711 Z M 0.472 14.895 L -0.46 15.258 C -0.183 15.969 0.198 16.591 0.803 17.197 L 1.511 16.489 L 2.218 15.782 C 1.822 15.387 1.588 15.005 1.405 14.533 L 0.472 14.895 Z M 1.511 16.489 L 0.803 17.197 C 1.409 17.802 2.031 18.183 2.742 18.46 L 3.105 17.528 L 3.467 16.595 C 2.995 16.412 2.613 16.178 2.218 15.782 L 1.511 16.489 Z M 3.105 17.528 L 2.742 18.46 C 3.428 18.726 4.191 18.897 5.244 18.945 L 5.289 17.946 L 5.335 16.947 C 4.472 16.908 3.926 16.774 3.467 16.595 L 3.105 17.528 Z M 5.289 17.946 L 5.244 18.945 C 6.227 18.99 6.551 19 9 19 L 9 18 L 9 17 C 6.561 17 6.272 16.99 5.335 16.947 L 5.289 17.946 Z M 9 18 L 9 19 C 11.449 19 11.773 18.99 12.756 18.945 L 12.711 17.946 L 12.665 16.947 C 11.728 16.99 11.439 17 9 17 L 9 18 Z M 12.711 17.946 L 12.756 18.945 C 13.809 18.897 14.572 18.726 15.258 18.46 L 14.895 17.528 L 14.533 16.595 C 14.074 16.774 13.528 16.908 12.665 16.947 L 12.711 17.946 Z M 14.895 17.528 L 15.258 18.46 C 15.969 18.183 16.591 17.802 17.197 17.197 L 16.489 16.489 L 15.782 15.782 C 15.387 16.178 15.005 16.412 14.533 16.595 L 14.895 17.528 Z M 16.489 16.489 L 17.197 17.197 C 17.802 16.591 18.183 15.969 18.46 15.258 L 17.527 14.895 L 16.595 14.533 C 16.412 15.005 16.178 15.387 15.782 15.782 L 16.489 16.489 Z M 17.527 14.895 L 18.46 15.258 C 18.726 14.572 18.897 13.809 18.945 12.756 L 17.946 12.711 L 16.947 12.665 C 16.907 13.528 16.774 14.074 16.595 14.533 L 17.527 14.895 Z M 17.946 12.711 L 18.945 12.756 C 18.99 11.774 19 11.449 19 9 L 18 9 L 17 9 C 17 11.439 16.99 11.728 16.947 12.665 L 17.946 12.711 Z M 18 9 L 19 9 C 19 6.551 18.99 6.227 18.945 5.244 L 17.946 5.289 L 16.947 5.335 C 16.99 6.272 17 6.561 17 9 L 18 9 Z M 17.946 5.289 L 18.945 5.244 C 18.897 4.191 18.726 3.428 18.46 2.742 L 17.527 3.105 L 16.595 3.467 C 16.774 3.926 16.907 4.472 16.947 5.335 L 17.946 5.289 Z M 17.527 3.105 L 18.46 2.742 C 18.183 2.031 17.802 1.409 17.197 0.803 L 16.489 1.511 L 15.782 2.218 C 16.178 2.613 16.412 2.995 16.595 3.467 L 17.527 3.105 Z M 16.489 1.511 L 17.197 0.803 C 16.591 0.198 15.969 -0.183 15.258 -0.46 L 14.895 0.473 L 14.533 1.405 C 15.005 1.588 15.387 1.822 15.782 2.218 L 16.489 1.511 Z M 14.895 0.473 L 15.258 -0.46 C 14.572 -0.726 13.809 -0.897 12.756 -0.945 L 12.711 0.054 L 12.665 1.053 C 13.528 1.093 14.074 1.226 14.533 1.405 L 14.895 0.473 Z M 12.711 0.054 L 12.756 -0.945 C 11.773 -0.99 11.449 -1 9 -1 L 9 0 L 9 1 C 11.439 1 11.728 1.01 12.665 1.053 L 12.711 0.054 Z M 9 4.378 L 9 3.378 C 5.895 3.378 3.378 5.895 3.378 9 L 4.378 9 L 5.378 9 C 5.378 7 7 5.378 9 5.378 L 9 4.378 Z M 4.378 9 L 3.378 9 C 3.378 12.105 5.895 14.622 9 14.622 L 9 13.622 L 9 12.622 C 7 12.622 5.378 11 5.378 9 L 4.378 9 Z M 9 13.622 L 9 14.622 C 12.105 14.622 14.622 12.105 14.622 9 L 13.622 9 L 12.622 9 C 12.622 11 11 12.622 9 12.622 L 9 13.622 Z M 13.622 9 L 14.622 9 C 14.622 5.895 12.105 3.378 9 3.378 L 9 4.378 L 9 5.378 C 11 5.378 12.622 7 12.622 9 L 13.622 9 Z M 9 12 L 9 11 C 7.895 11 7 10.105 7 9 L 6 9 L 5 9 C 5 11.209 6.791 13 9 13 L 9 12 Z M 6 9 L 7 9 C 7 7.895 7.895 7 9 7 L 9 6 L 9 5 C 6.791 5 5 6.791 5 9 L 6 9 Z M 9 6 L 9 7 C 10.105 7 11 7.895 11 9 L 12 9 L 13 9 C 13 6.791 11.209 5 9 5 L 9 6 Z M 12 9 L 11 9 C 11 10.105 10.105 11 9 11 L 9 12 L 9 13 C 11.209 13 13 11.209 13 9 L 12 9 Z M 14.884 4.196 L 13.884 4.196 C 13.884 4.24 13.848 4.276 13.804 4.276 L 13.804 5.276 L 13.804 6.276 C 14.953 6.276 15.884 5.345 15.884 4.196 L 14.884 4.196 Z M 13.804 5.276 L 13.804 4.276 C 13.76 4.276 13.724 4.24 13.724 4.196 L 12.724 4.196 L 11.724 4.196 C 11.724 5.345 12.655 6.276 13.804 6.276 L 13.804 5.276 Z M 12.724 4.196 L 13.724 4.196 C 13.724 4.152 13.76 4.116 13.804 4.116 L 13.804 3.116 L 13.804 2.116 C 12.655 2.116 11.724 3.047 11.724 4.196 L 12.724 4.196 Z M 13.804 3.116 L 13.804 4.116 C 13.848 4.116 13.884 4.152 13.884 4.196 L 14.884 4.196 L 15.884 4.196 C 15.884 3.047 14.953 2.116 13.804 2.116 L 13.804 3.116 Z\" fill=\"rgb(36,36,36)\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 3 3)\"/>"
  },
  "ButtonSocialPintrest": {
    viewBox: "0 0 40 40",
    body: "<path d=\"M 3.33 19.006 C 4.398 18.065 5.131 16.725 5.489 15.352 C 5.633 14.81 6.222 12.593 6.222 12.593 C 6.603 13.317 7.728 13.926 8.911 13.926 C 12.455 13.926 15.006 10.711 15.006 6.704 C 15.006 2.867 11.837 0 7.763 0 C 2.689 0 0 3.363 0 7.023 C 0 8.722 0.918 10.842 2.384 11.515 C 2.603 11.623 2.724 11.572 2.776 11.356 C 2.811 11.19 3.013 10.409 3.105 10.039 C 3.134 9.925 3.122 9.816 3.024 9.702 C 2.539 9.121 2.147 8.049 2.147 7.057 C 2.147 4.498 4.109 2.018 7.451 2.018 C 10.337 2.018 12.357 3.956 12.357 6.738 C 12.357 9.879 10.752 12.057 8.663 12.057 C 7.509 12.057 6.643 11.116 6.926 9.959 C 7.26 8.579 7.901 7.092 7.901 6.1 C 7.901 5.21 7.422 4.469 6.412 4.469 C 5.229 4.469 4.288 5.672 4.288 7.291 C 4.288 8.317 4.634 9.013 4.634 9.013 C 4.634 9.013 3.469 13.875 3.255 14.782 C 3.018 15.785 3.111 17.193 3.215 18.111 L 3.319 19.011 L 3.33 19.006 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 5 2) matrix(1 0 0 1 -0.006 -0.006)\"/>"
  },
  "ButtonSocialTiktok": {
    viewBox: "0 0 40 40",
    body: "<path d=\"M 14.008 3.85 C 13.883 3.787 13.762 3.718 13.644 3.643 C 13.302 3.423 12.989 3.163 12.711 2.87 C 12.015 2.094 11.755 1.306 11.659 0.754 L 11.663 0.754 C 11.583 0.296 11.616 0 11.621 0 L 8.45 0 L 8.45 11.954 C 8.45 12.114 8.45 12.273 8.443 12.43 C 8.443 12.449 8.442 12.467 8.44 12.488 C 8.44 12.497 8.44 12.506 8.438 12.515 C 8.438 12.517 8.438 12.519 8.438 12.521 C 8.405 12.95 8.264 13.365 8.028 13.728 C 7.792 14.091 7.468 14.392 7.084 14.605 C 6.684 14.827 6.232 14.943 5.772 14.942 C 4.295 14.942 3.098 13.768 3.098 12.317 C 3.098 10.867 4.295 9.693 5.772 9.693 C 6.052 9.692 6.33 9.735 6.596 9.82 L 6.599 6.672 C 5.792 6.57 4.972 6.633 4.191 6.856 C 3.41 7.079 2.685 7.457 2.061 7.966 C 1.515 8.429 1.056 8.982 0.704 9.599 C 0.57 9.824 0.065 10.728 0.004 12.195 C -0.035 13.028 0.222 13.891 0.344 14.247 L 0.344 14.255 C 0.421 14.465 0.719 15.181 1.205 15.786 C 1.597 16.27 2.059 16.696 2.578 17.049 L 2.578 17.041 L 2.586 17.049 C 4.121 18.066 5.823 17.999 5.823 17.999 C 6.117 17.987 7.104 17.999 8.225 17.481 C 9.468 16.907 10.175 16.052 10.175 16.052 C 10.627 15.541 10.987 14.958 11.238 14.33 C 11.525 13.594 11.621 12.712 11.621 12.36 L 11.621 6.018 C 11.659 6.041 12.172 6.371 12.172 6.371 C 12.172 6.371 12.91 6.832 14.061 7.133 C 14.887 7.346 16 7.391 16 7.391 L 16 4.322 C 15.61 4.364 14.818 4.244 14.008 3.85 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 4 3)\"/><path d=\"M 14.008 3.85 L 13.557 4.743 L 13.564 4.746 L 13.57 4.749 L 14.008 3.85 Z M 13.644 3.643 L 13.102 4.484 L 13.108 4.488 L 13.644 3.643 Z M 12.711 2.87 L 11.966 3.538 L 11.975 3.548 L 11.985 3.558 L 12.711 2.87 Z M 11.659 0.754 L 11.659 -0.246 L 10.47 -0.246 L 10.674 0.925 L 11.659 0.754 Z M 11.663 0.754 L 11.663 1.754 L 12.853 1.754 L 12.648 0.582 L 11.663 0.754 Z M 8.45 0 L 8.45 -1 L 7.45 -1 L 7.45 0 L 8.45 0 Z M 8.443 12.43 L 7.444 12.385 L 7.443 12.407 L 7.443 12.43 L 8.443 12.43 Z M 8.44 12.488 L 7.442 12.433 L 7.44 12.461 L 7.44 12.488 L 8.44 12.488 Z M 8.438 12.515 L 7.461 12.306 L 7.438 12.409 L 7.438 12.515 L 8.438 12.515 Z M 8.438 12.521 L 9.435 12.599 L 9.438 12.56 L 9.438 12.521 L 8.438 12.521 Z M 7.084 14.605 L 6.599 13.73 L 6.599 13.73 L 7.084 14.605 Z M 5.772 14.942 L 5.773 13.942 L 5.772 13.942 L 5.772 14.942 Z M 5.772 9.693 L 5.772 10.693 L 5.773 10.693 L 5.772 9.693 Z M 6.596 9.82 L 6.293 10.773 L 7.594 11.186 L 7.596 9.821 L 6.596 9.82 Z M 6.599 6.672 L 7.599 6.673 L 7.6 5.79 L 6.724 5.68 L 6.599 6.672 Z M 2.061 7.966 L 1.429 7.192 L 1.422 7.198 L 1.415 7.203 L 2.061 7.966 Z M 0.704 9.599 L 1.563 10.11 L 1.568 10.102 L 1.573 10.094 L 0.704 9.599 Z M 0.004 12.195 L 1.003 12.241 L 1.003 12.237 L 0.004 12.195 Z M 0.344 14.247 L 1.344 14.247 L 1.344 14.081 L 1.29 13.923 L 0.344 14.247 Z M 0.344 14.255 L -0.656 14.255 L -0.656 14.432 L -0.595 14.599 L 0.344 14.255 Z M 1.205 15.786 L 0.426 16.412 L 0.427 16.414 L 1.205 15.786 Z M 2.578 17.049 L 2.016 17.876 L 3.578 18.939 L 3.578 17.049 L 2.578 17.049 Z M 2.578 17.041 L 3.276 16.325 L 1.578 14.67 L 1.578 17.041 L 2.578 17.041 Z M 2.586 17.049 L 1.888 17.765 L 1.955 17.831 L 2.034 17.883 L 2.586 17.049 Z M 5.823 17.999 L 5.862 18.998 L 5.862 18.998 L 5.823 17.999 Z M 8.225 17.481 L 7.805 16.573 L 7.805 16.573 L 8.225 17.481 Z M 10.175 16.052 L 9.426 15.389 L 9.415 15.402 L 9.405 15.414 L 10.175 16.052 Z M 11.238 14.33 L 12.167 14.701 L 12.17 14.693 L 11.238 14.33 Z M 11.621 6.018 L 12.126 5.155 L 10.621 4.274 L 10.621 6.018 L 11.621 6.018 Z M 12.172 6.371 L 11.63 7.211 L 11.636 7.215 L 11.642 7.219 L 12.172 6.371 Z M 14.061 7.133 L 13.809 8.1 L 13.81 8.101 L 14.061 7.133 Z M 16 7.391 L 15.96 8.39 L 17 8.433 L 17 7.391 L 16 7.391 Z M 16 4.322 L 17 4.322 L 17 3.211 L 15.895 3.328 L 16 4.322 Z M 14.008 3.85 L 14.458 2.957 C 14.362 2.909 14.27 2.856 14.18 2.799 L 13.644 3.643 L 13.108 4.488 C 13.254 4.58 13.404 4.665 13.557 4.743 L 14.008 3.85 Z M 13.644 3.643 L 14.186 2.803 C 13.911 2.625 13.659 2.417 13.436 2.182 L 12.711 2.87 L 11.985 3.558 C 12.319 3.91 12.694 4.221 13.102 4.484 L 13.644 3.643 Z M 12.711 2.87 L 13.455 2.203 C 12.908 1.592 12.715 0.989 12.644 0.583 L 11.659 0.754 L 10.674 0.925 C 10.795 1.623 11.121 2.595 11.966 3.538 L 12.711 2.87 Z M 11.659 0.754 L 11.659 1.754 L 11.663 1.754 L 11.663 0.754 L 11.663 -0.246 L 11.659 -0.246 L 11.659 0.754 Z M 11.663 0.754 L 12.648 0.582 C 12.618 0.411 12.611 0.278 12.61 0.197 C 12.61 0.156 12.611 0.132 12.611 0.126 C 12.612 0.122 12.611 0.131 12.609 0.149 C 12.608 0.154 12.604 0.181 12.597 0.216 C 12.594 0.228 12.583 0.278 12.561 0.34 C 12.552 0.364 12.523 0.444 12.465 0.535 C 12.437 0.58 12.375 0.672 12.269 0.762 C 12.164 0.851 11.942 1 11.621 1 L 11.621 0 L 11.621 -1 C 11.3 -1 11.077 -0.851 10.973 -0.762 C 10.867 -0.671 10.804 -0.58 10.776 -0.535 C 10.718 -0.443 10.688 -0.363 10.679 -0.338 C 10.657 -0.275 10.646 -0.224 10.643 -0.21 C 10.634 -0.17 10.629 -0.136 10.627 -0.121 C 10.622 -0.085 10.619 -0.05 10.617 -0.019 C 10.612 0.045 10.609 0.123 10.61 0.214 C 10.611 0.395 10.627 0.639 10.678 0.926 L 11.663 0.754 Z M 11.621 0 L 11.621 -1 L 8.45 -1 L 8.45 0 L 8.45 1 L 11.621 1 L 11.621 0 Z M 8.45 0 L 7.45 0 L 7.45 11.954 L 8.45 11.954 L 9.45 11.954 L 9.45 0 L 8.45 0 Z M 8.45 11.954 L 7.45 11.954 C 7.45 12.118 7.45 12.254 7.444 12.385 L 8.443 12.43 L 9.442 12.474 C 9.451 12.291 9.45 12.11 9.45 11.954 L 8.45 11.954 Z M 8.443 12.43 L 7.443 12.43 C 7.443 12.418 7.444 12.409 7.444 12.402 C 7.444 12.396 7.444 12.392 7.444 12.393 C 7.444 12.393 7.444 12.394 7.444 12.396 C 7.444 12.397 7.444 12.398 7.444 12.399 C 7.444 12.4 7.444 12.402 7.444 12.404 C 7.443 12.41 7.443 12.421 7.442 12.433 L 8.44 12.488 L 9.439 12.543 C 9.439 12.545 9.439 12.545 9.439 12.542 C 9.439 12.541 9.44 12.531 9.44 12.523 C 9.441 12.506 9.443 12.471 9.443 12.43 L 8.443 12.43 Z M 8.44 12.488 L 7.44 12.488 C 7.44 12.496 7.44 12.474 7.442 12.447 C 7.443 12.417 7.447 12.367 7.461 12.306 L 8.438 12.515 L 9.416 12.724 C 9.431 12.653 9.437 12.594 9.439 12.555 C 9.441 12.519 9.44 12.488 9.44 12.488 L 8.44 12.488 Z M 8.438 12.515 L 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.515 7.438 12.515 C 7.438 12.515 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.516 7.438 12.516 7.438 12.516 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.517 7.438 12.517 7.438 12.517 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.518 C 7.438 12.518 7.438 12.518 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.519 C 7.438 12.519 7.438 12.519 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.52 7.438 12.52 C 7.438 12.52 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 C 7.438 12.521 7.438 12.521 7.438 12.521 L 8.438 12.521 L 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.521 9.438 12.521 C 9.438 12.521 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.52 9.438 12.52 9.438 12.52 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.519 9.438 12.519 9.438 12.519 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.518 C 9.438 12.518 9.438 12.518 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.517 C 9.438 12.517 9.438 12.517 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.516 9.438 12.516 C 9.438 12.516 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 C 9.438 12.515 9.438 12.515 9.438 12.515 L 8.438 12.515 Z M 8.438 12.521 L 7.441 12.444 C 7.421 12.705 7.335 12.959 7.189 13.183 L 8.028 13.728 L 8.866 14.273 C 9.193 13.771 9.389 13.196 9.435 12.599 L 8.438 12.521 Z M 8.028 13.728 L 7.189 13.183 C 7.044 13.407 6.842 13.596 6.599 13.73 L 7.084 14.605 L 7.569 15.48 C 8.093 15.189 8.54 14.775 8.866 14.273 L 8.028 13.728 Z M 7.084 14.605 L 6.599 13.73 C 6.349 13.869 6.064 13.943 5.773 13.942 L 5.772 14.942 L 5.771 15.942 C 6.4 15.943 7.02 15.784 7.569 15.479 L 7.084 14.605 Z M 5.772 14.942 L 5.772 13.942 C 4.829 13.942 4.098 13.198 4.098 12.317 L 3.098 12.317 L 2.098 12.317 C 2.098 14.338 3.761 15.942 5.772 15.942 L 5.772 14.942 Z M 3.098 12.317 L 4.098 12.317 C 4.098 11.437 4.829 10.693 5.772 10.693 L 5.772 9.693 L 5.772 8.693 C 3.761 8.693 2.098 10.297 2.098 12.317 L 3.098 12.317 Z M 5.772 9.693 L 5.773 10.693 C 5.95 10.692 6.125 10.719 6.293 10.773 L 6.596 9.82 L 6.898 8.867 C 6.534 8.751 6.154 8.692 5.771 8.693 L 5.772 9.693 Z M 6.596 9.82 L 7.596 9.821 L 7.599 6.673 L 6.599 6.672 L 5.599 6.671 L 5.596 9.818 L 6.596 9.82 Z M 6.599 6.672 L 6.724 5.68 C 5.784 5.561 4.828 5.634 3.917 5.894 L 4.191 6.856 L 4.466 7.817 C 5.117 7.632 5.801 7.579 6.474 7.664 L 6.599 6.672 Z M 4.191 6.856 L 3.917 5.894 C 3.006 6.154 2.159 6.595 1.429 7.192 L 2.061 7.966 L 2.694 8.741 C 3.211 8.318 3.814 8.003 4.466 7.817 L 4.191 6.856 Z M 2.061 7.966 L 1.415 7.203 C 0.78 7.741 0.245 8.384 -0.165 9.104 L 0.704 9.599 L 1.573 10.094 C 1.866 9.579 2.25 9.118 2.708 8.729 L 2.061 7.966 Z M 0.704 9.599 L -0.156 9.088 C -0.342 9.401 -0.925 10.467 -0.995 12.154 L 0.004 12.195 L 1.003 12.237 C 1.055 10.988 1.482 10.247 1.563 10.11 L 0.704 9.599 Z M 0.004 12.195 L -0.995 12.149 C -1.042 13.176 -0.734 14.185 -0.602 14.572 L 0.344 14.247 L 1.29 13.923 C 1.178 13.597 0.973 12.88 1.003 12.241 L 0.004 12.195 Z M 0.344 14.247 L -0.656 14.247 L -0.656 14.255 L 0.344 14.255 L 1.344 14.255 L 1.344 14.247 L 0.344 14.247 Z M 0.344 14.255 L -0.595 14.599 C -0.5 14.857 -0.157 15.688 0.426 16.412 L 1.205 15.786 L 1.984 15.159 C 1.595 14.675 1.342 14.073 1.283 13.911 L 0.344 14.255 Z M 1.205 15.786 L 0.427 16.414 C 0.881 16.976 1.416 17.468 2.016 17.876 L 2.578 17.049 L 3.141 16.222 C 2.702 15.924 2.312 15.565 1.983 15.157 L 1.205 15.786 Z M 2.578 17.049 L 3.578 17.049 L 3.578 17.041 L 2.578 17.041 L 1.578 17.041 L 1.578 17.049 L 2.578 17.049 Z M 2.578 17.041 L 1.88 17.757 L 1.888 17.765 L 2.586 17.049 L 3.284 16.333 L 3.276 16.325 L 2.578 17.041 Z M 2.586 17.049 L 2.034 17.883 C 2.948 18.488 3.898 18.763 4.604 18.89 C 4.959 18.953 5.262 18.981 5.48 18.992 C 5.59 18.998 5.679 19 5.743 19 C 5.776 19 5.802 19 5.822 18.999 C 5.832 18.999 5.84 18.999 5.847 18.999 C 5.85 18.999 5.853 18.999 5.856 18.999 C 5.857 18.999 5.858 18.998 5.859 18.998 C 5.859 18.998 5.86 18.998 5.86 18.998 C 5.861 18.998 5.861 18.998 5.861 18.998 C 5.861 18.998 5.862 18.998 5.823 17.999 C 5.783 17 5.784 17 5.784 17 C 5.784 17 5.784 17 5.785 17 C 5.785 17 5.785 17 5.786 17 C 5.786 17 5.787 17 5.787 17 C 5.788 17 5.788 17 5.788 17 C 5.789 17 5.787 17 5.784 17 C 5.779 17 5.767 17 5.75 17 C 5.715 17 5.659 16.999 5.585 16.995 C 5.436 16.987 5.217 16.968 4.956 16.921 C 4.427 16.826 3.759 16.626 3.138 16.215 L 2.586 17.049 Z M 5.823 17.999 L 5.862 18.998 C 6.143 18.987 7.32 19.001 8.644 18.389 L 8.225 17.481 L 7.805 16.573 C 6.888 16.997 6.092 16.988 5.783 17 L 5.823 17.999 Z M 8.225 17.481 L 8.644 18.389 C 9.369 18.054 9.934 17.64 10.318 17.31 C 10.511 17.144 10.661 16.997 10.766 16.888 C 10.818 16.833 10.86 16.788 10.89 16.754 C 10.905 16.737 10.917 16.723 10.926 16.712 C 10.931 16.707 10.935 16.702 10.938 16.698 C 10.94 16.696 10.941 16.695 10.942 16.693 C 10.943 16.692 10.944 16.692 10.944 16.691 C 10.944 16.691 10.945 16.69 10.945 16.69 C 10.945 16.69 10.945 16.69 10.945 16.69 C 10.946 16.689 10.946 16.689 10.175 16.052 C 9.405 15.414 9.405 15.414 9.405 15.414 C 9.405 15.414 9.405 15.414 9.405 15.414 C 9.406 15.413 9.406 15.413 9.406 15.413 C 9.406 15.412 9.407 15.412 9.407 15.412 C 9.407 15.411 9.408 15.411 9.408 15.41 C 9.408 15.41 9.408 15.41 9.407 15.411 C 9.406 15.413 9.402 15.418 9.395 15.425 C 9.381 15.441 9.358 15.467 9.325 15.501 C 9.258 15.57 9.154 15.673 9.014 15.793 C 8.734 16.034 8.323 16.334 7.805 16.573 L 8.225 17.481 Z M 10.175 16.052 L 10.924 16.714 C 11.452 16.118 11.872 15.437 12.167 14.701 L 11.238 14.33 L 10.31 13.958 C 10.101 14.48 9.803 14.964 9.426 15.389 L 10.175 16.052 Z M 11.238 14.33 L 12.17 14.693 C 12.511 13.818 12.621 12.808 12.621 12.36 L 11.621 12.36 L 10.621 12.36 C 10.621 12.616 10.539 13.37 10.307 13.966 L 11.238 14.33 Z M 11.621 12.36 L 12.621 12.36 L 12.621 6.018 L 11.621 6.018 L 10.621 6.018 L 10.621 12.36 L 11.621 12.36 Z M 11.621 6.018 L 11.116 6.881 C 11.111 6.878 11.22 6.947 11.37 7.044 C 11.436 7.087 11.501 7.128 11.549 7.16 C 11.574 7.175 11.594 7.188 11.608 7.197 C 11.615 7.202 11.62 7.205 11.624 7.208 C 11.626 7.209 11.627 7.21 11.628 7.21 C 11.629 7.211 11.629 7.211 11.629 7.211 C 11.629 7.211 11.629 7.211 11.629 7.211 C 11.63 7.211 11.63 7.211 11.63 7.211 C 11.63 7.211 11.63 7.211 11.63 7.211 C 11.63 7.211 11.63 7.211 12.172 6.371 C 12.714 5.531 12.714 5.531 12.714 5.531 C 12.713 5.531 12.713 5.531 12.713 5.531 C 12.713 5.531 12.713 5.53 12.713 5.53 C 12.713 5.53 12.713 5.53 12.713 5.53 C 12.713 5.53 12.712 5.53 12.712 5.53 C 12.711 5.529 12.71 5.528 12.708 5.527 C 12.704 5.524 12.698 5.521 12.691 5.516 C 12.677 5.507 12.657 5.494 12.632 5.478 C 12.584 5.447 12.518 5.405 12.451 5.362 C 12.336 5.288 12.169 5.18 12.126 5.155 L 11.621 6.018 Z M 12.172 6.371 C 11.642 7.219 11.642 7.219 11.642 7.219 C 11.642 7.219 11.642 7.219 11.642 7.219 C 11.643 7.22 11.643 7.22 11.643 7.22 C 11.644 7.22 11.644 7.221 11.645 7.221 C 11.646 7.222 11.648 7.223 11.649 7.224 C 11.652 7.226 11.656 7.228 11.661 7.231 C 11.671 7.237 11.683 7.244 11.698 7.253 C 11.729 7.271 11.771 7.295 11.823 7.324 C 11.928 7.382 12.076 7.459 12.263 7.546 C 12.634 7.719 13.164 7.932 13.809 8.1 L 14.061 7.133 L 14.313 6.165 C 13.807 6.033 13.392 5.865 13.106 5.732 C 12.964 5.666 12.856 5.61 12.787 5.571 C 12.752 5.552 12.727 5.538 12.713 5.529 C 12.705 5.525 12.701 5.522 12.699 5.521 C 12.698 5.521 12.698 5.521 12.698 5.521 C 12.698 5.521 12.699 5.521 12.699 5.522 C 12.7 5.522 12.7 5.522 12.7 5.522 C 12.7 5.522 12.701 5.522 12.701 5.523 C 12.701 5.523 12.701 5.523 12.701 5.523 C 12.701 5.523 12.702 5.523 12.172 6.371 Z M 14.061 7.133 L 13.81 8.101 C 14.298 8.227 14.842 8.297 15.241 8.337 C 15.446 8.357 15.623 8.371 15.749 8.379 C 15.812 8.383 15.863 8.386 15.899 8.388 C 15.917 8.389 15.931 8.389 15.942 8.39 C 15.947 8.39 15.951 8.39 15.954 8.39 C 15.955 8.39 15.957 8.39 15.958 8.39 C 15.958 8.39 15.958 8.39 15.959 8.39 C 15.959 8.39 15.959 8.39 15.959 8.39 C 15.959 8.39 15.959 8.39 15.959 8.39 C 15.96 8.39 15.96 8.39 16 7.391 C 16.04 6.392 16.04 6.392 16.041 6.392 C 16.041 6.392 16.041 6.392 16.041 6.392 C 16.041 6.392 16.041 6.392 16.041 6.392 C 16.041 6.392 16.041 6.392 16.041 6.392 C 16.041 6.392 16.04 6.392 16.04 6.392 C 16.038 6.392 16.036 6.392 16.033 6.392 C 16.026 6.391 16.016 6.391 16.002 6.39 C 15.974 6.389 15.931 6.386 15.878 6.383 C 15.769 6.376 15.616 6.365 15.439 6.347 C 15.075 6.311 14.65 6.252 14.311 6.164 L 14.061 7.133 Z M 16 7.391 L 17 7.391 L 17 4.322 L 16 4.322 L 15 4.322 L 15 7.391 L 16 7.391 Z M 16 4.322 L 15.895 3.328 C 15.84 3.334 15.657 3.332 15.37 3.271 C 15.096 3.213 14.773 3.11 14.445 2.95 L 14.008 3.85 L 13.57 4.749 C 14.501 5.202 15.482 5.383 16.105 5.317 L 16 4.322 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8) matrix(1 0 0 1 4 3)\"/>"
  },
  "IconOutlineArrowNarrowRight": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 14.707 -0.707 C 14.317 -1.098 13.683 -1.098 13.293 -0.707 C 12.902 -0.317 12.902 0.317 13.293 0.707 L 14 0 L 14.707 -0.707 Z M 18 4 L 18.707 4.707 C 19.098 4.317 19.098 3.683 18.707 3.293 L 18 4 Z M 13.293 7.293 C 12.902 7.683 12.902 8.317 13.293 8.707 C 13.683 9.098 14.317 9.098 14.707 8.707 L 14 8 L 13.293 7.293 Z M 0 3 C -0.552 3 -1 3.448 -1 4 C -1 4.552 -0.552 5 0 5 L 0 4 L 0 3 Z M 14 0 L 13.293 0.707 L 17.293 4.707 L 18 4 L 18.707 3.293 L 14.707 -0.707 L 14 0 Z M 18 4 L 17.293 3.293 L 13.293 7.293 L 14 8 L 14.707 8.707 L 18.707 4.707 L 18 4 Z M 18 4 L 18 3 L 0 3 L 0 4 L 0 5 L 18 5 L 18 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 8)\"/>"
  },
  "IconOutlineArrowRight": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 11.707 -0.707 C 11.317 -1.098 10.683 -1.098 10.293 -0.707 C 9.902 -0.317 9.902 0.317 10.293 0.707 L 11 0 L 11.707 -0.707 Z M 18 7 L 18.707 7.707 C 19.098 7.317 19.098 6.683 18.707 6.293 L 18 7 Z M 10.293 13.293 C 9.902 13.683 9.902 14.317 10.293 14.707 C 10.683 15.098 11.317 15.098 11.707 14.707 L 11 14 L 10.293 13.293 Z M 0 6 C -0.552 6 -1 6.448 -1 7 C -1 7.552 -0.552 8 0 8 L 0 7 L 0 6 Z M 11 0 L 10.293 0.707 L 17.293 7.707 L 18 7 L 18.707 6.293 L 11.707 -0.707 L 11 0 Z M 18 7 L 17.293 6.293 L 10.293 13.293 L 11 14 L 11.707 14.707 L 18.707 7.707 L 18 7 Z M 18 7 L 18 6 L 0 6 L 0 7 L 0 8 L 18 8 L 18 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
  },
  "IconOutlineCheck": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 0.707 5.293 C 0.317 4.902 -0.317 4.902 -0.707 5.293 C -1.098 5.683 -1.098 6.317 -0.707 6.707 L 0 6 L 0.707 5.293 Z M 4 10 L 3.293 10.707 C 3.683 11.098 4.317 11.098 4.707 10.707 L 4 10 Z M 14.707 0.707 C 15.098 0.317 15.098 -0.317 14.707 -0.707 C 14.317 -1.098 13.683 -1.098 13.293 -0.707 L 14 0 L 14.707 0.707 Z M 0 6 L -0.707 6.707 L 3.293 10.707 L 4 10 L 4.707 9.293 L 0.707 5.293 L 0 6 Z M 4 10 L 4.707 10.707 L 14.707 0.707 L 14 0 L 13.293 -0.707 L 3.293 9.293 L 4 10 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 7)\"/>"
  },
  "IconOutlineChevronDown": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 14.707 0.707 C 15.098 0.317 15.098 -0.317 14.707 -0.707 C 14.317 -1.098 13.683 -1.098 13.293 -0.707 L 14 0 L 14.707 0.707 Z M 7 7 L 6.293 7.707 C 6.683 8.098 7.317 8.098 7.707 7.707 L 7 7 Z M 0.707 -0.707 C 0.317 -1.098 -0.317 -1.098 -0.707 -0.707 C -1.098 -0.317 -1.098 0.317 -0.707 0.707 L 0 0 L 0.707 -0.707 Z M 14 0 L 13.293 -0.707 L 6.293 6.293 L 7 7 L 7.707 7.707 L 14.707 0.707 L 14 0 Z M 7 7 L 7.707 6.293 L 0.707 -0.707 L 0 0 L -0.707 0.707 L 6.293 7.707 L 7 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 9)\"/>"
  },
  "IconOutlineChevronLeft": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 6.293 14.707 C 6.683 15.098 7.317 15.098 7.707 14.707 C 8.098 14.317 8.098 13.683 7.707 13.293 L 7 14 L 6.293 14.707 Z M 0 7 L -0.707 6.293 C -1.098 6.683 -1.098 7.317 -0.707 7.707 L 0 7 Z M 7.707 0.707 C 8.098 0.317 8.098 -0.317 7.707 -0.707 C 7.317 -1.098 6.683 -1.098 6.293 -0.707 L 7 0 L 7.707 0.707 Z M 7 14 L 7.707 13.293 L 0.707 6.293 L 0 7 L -0.707 7.707 L 6.293 14.707 L 7 14 Z M 0 7 L 0.707 7.707 L 7.707 0.707 L 7 0 L 6.293 -0.707 L -0.707 6.293 L 0 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 5)\"/>"
  },
  "IconOutlineChevronRight": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 0.707 -0.707 C 0.317 -1.098 -0.317 -1.098 -0.707 -0.707 C -1.098 -0.317 -1.098 0.317 -0.707 0.707 L 0 0 L 0.707 -0.707 Z M 7 7 L 7.707 7.707 C 8.098 7.317 8.098 6.683 7.707 6.293 L 7 7 Z M -0.707 13.293 C -1.098 13.683 -1.098 14.317 -0.707 14.707 C -0.317 15.098 0.317 15.098 0.707 14.707 L 0 14 L -0.707 13.293 Z M 0 0 L -0.707 0.707 L 6.293 7.707 L 7 7 L 7.707 6.293 L 0.707 -0.707 L 0 0 Z M 7 7 L 6.293 6.293 L -0.707 13.293 L 0 14 L 0.707 14.707 L 7.707 7.707 L 7 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 9 5)\"/>"
  },
  "IconOutlineGift": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 8 18 C 8 18.552 8.448 19 9 19 C 9.552 19 10 18.552 10 18 L 9 18 L 8 18 Z M 9 2.5 L 8 2.5 L 9 2.5 Z M 6.5 5 L 6.5 6 L 6.5 5 Z M 0 7 L -1 7 L 0 7 Z M 2 5 L 2 6 L 2 5 Z M 2 16 L 1 16 L 2 16 Z M 9 5 L 8 5 L 8 18 L 9 18 L 10 18 L 10 5 L 9 5 Z M 9 5 L 10 5 L 10 3 L 9 3 L 8 3 L 8 5 L 9 5 Z M 9 3 L 10 3 C 10 2.802 10.059 2.609 10.169 2.444 L 9.337 1.889 L 8.506 1.333 C 8.176 1.827 8 2.407 8 3 L 9 3 Z M 9.337 1.889 L 10.169 2.444 C 10.278 2.28 10.435 2.152 10.617 2.076 L 10.235 1.152 L 9.852 0.228 C 9.304 0.455 8.835 0.84 8.506 1.333 L 9.337 1.889 Z M 10.235 1.152 L 10.617 2.076 C 10.8 2 11.001 1.981 11.195 2.019 L 11.39 1.038 L 11.585 0.058 C 11.003 -0.058 10.4 0.001 9.852 0.228 L 10.235 1.152 Z M 11.39 1.038 L 11.195 2.019 C 11.389 2.058 11.567 2.153 11.707 2.293 L 12.414 1.586 L 13.121 0.879 C 12.702 0.459 12.167 0.173 11.585 0.058 L 11.39 1.038 Z M 12.414 1.586 L 11.707 2.293 C 11.847 2.433 11.942 2.611 11.981 2.805 L 12.962 2.61 L 13.942 2.415 C 13.827 1.833 13.541 1.298 13.121 0.879 L 12.414 1.586 Z M 12.962 2.61 L 11.981 2.805 C 12.019 2.999 12 3.2 11.924 3.383 L 12.848 3.765 L 13.772 4.148 C 13.999 3.6 14.058 2.997 13.942 2.415 L 12.962 2.61 Z M 12.848 3.765 L 11.924 3.383 C 11.848 3.565 11.72 3.722 11.556 3.831 L 12.111 4.663 L 12.667 5.494 C 13.16 5.165 13.545 4.696 13.772 4.148 L 12.848 3.765 Z M 12.111 4.663 L 11.556 3.831 C 11.391 3.941 11.198 4 11 4 L 11 5 L 11 6 C 11.593 6 12.173 5.824 12.667 5.494 L 12.111 4.663 Z M 11 5 L 11 4 L 9 4 L 9 5 L 9 6 L 11 6 L 11 5 Z M 9 5 L 10 5 L 10 2.5 L 9 2.5 L 8 2.5 L 8 5 L 9 5 Z M 9 2.5 L 10 2.5 C 10 1.808 9.795 1.131 9.41 0.556 L 8.579 1.111 L 7.747 1.667 C 7.912 1.913 8 2.203 8 2.5 L 9 2.5 Z M 8.579 1.111 L 9.41 0.556 C 9.026 -0.02 8.479 -0.469 7.839 -0.734 L 7.457 0.19 L 7.074 1.114 C 7.348 1.228 7.582 1.42 7.747 1.667 L 8.579 1.111 Z M 7.457 0.19 L 7.839 -0.734 C 7.2 -0.998 6.496 -1.068 5.817 -0.933 L 6.012 0.048 L 6.207 1.029 C 6.498 0.971 6.8 1.001 7.074 1.114 L 7.457 0.19 Z M 6.012 0.048 L 5.817 -0.933 C 5.138 -0.798 4.515 -0.464 4.025 0.025 L 4.732 0.732 L 5.439 1.439 C 5.649 1.23 5.916 1.087 6.207 1.029 L 6.012 0.048 Z M 4.732 0.732 L 4.025 0.025 C 3.536 0.515 3.202 1.138 3.067 1.817 L 4.048 2.012 L 5.029 2.207 C 5.087 1.916 5.23 1.649 5.439 1.439 L 4.732 0.732 Z M 4.048 2.012 L 3.067 1.817 C 2.932 2.496 3.002 3.2 3.266 3.839 L 4.19 3.457 L 5.114 3.074 C 5.001 2.8 4.971 2.498 5.029 2.207 L 4.048 2.012 Z M 4.19 3.457 L 3.266 3.839 C 3.531 4.479 3.98 5.026 4.556 5.41 L 5.111 4.579 L 5.667 3.747 C 5.42 3.582 5.228 3.348 5.114 3.074 L 4.19 3.457 Z M 5.111 4.579 L 4.556 5.41 C 5.131 5.795 5.808 6 6.5 6 L 6.5 5 L 6.5 4 C 6.203 4 5.913 3.912 5.667 3.747 L 5.111 4.579 Z M 6.5 5 L 6.5 6 L 9 6 L 9 5 L 9 4 L 6.5 4 L 6.5 5 Z M 2 9 L 2 10 L 16 10 L 16 9 L 16 8 L 2 8 L 2 9 Z M 2 9 L 2 8 C 1.735 8 1.48 7.895 1.293 7.707 L 0.586 8.414 L -0.121 9.121 C 0.441 9.684 1.204 10 2 10 L 2 9 Z M 0.586 8.414 L 1.293 7.707 C 1.105 7.52 1 7.265 1 7 L 0 7 L -1 7 C -1 7.796 -0.684 8.559 -0.121 9.121 L 0.586 8.414 Z M 0 7 L 1 7 C 1 6.735 1.105 6.48 1.293 6.293 L 0.586 5.586 L -0.121 4.879 C -0.684 5.441 -1 6.204 -1 7 L 0 7 Z M 0.586 5.586 L 1.293 6.293 C 1.48 6.105 1.735 6 2 6 L 2 5 L 2 4 C 1.204 4 0.441 4.316 -0.121 4.879 L 0.586 5.586 Z M 2 5 L 2 6 L 16 6 L 16 5 L 16 4 L 2 4 L 2 5 Z M 16 5 L 16 6 C 16.265 6 16.52 6.105 16.707 6.293 L 17.414 5.586 L 18.121 4.879 C 17.559 4.316 16.796 4 16 4 L 16 5 Z M 17.414 5.586 L 16.707 6.293 C 16.895 6.48 17 6.735 17 7 L 18 7 L 19 7 C 19 6.204 18.684 5.441 18.121 4.879 L 17.414 5.586 Z M 18 7 L 17 7 C 17 7.265 16.895 7.52 16.707 7.707 L 17.414 8.414 L 18.121 9.121 C 18.684 8.559 19 7.796 19 7 L 18 7 Z M 17.414 8.414 L 16.707 7.707 C 16.52 7.895 16.265 8 16 8 L 16 9 L 16 10 C 16.796 10 17.559 9.684 18.121 9.121 L 17.414 8.414 Z M 2 9 L 1 9 L 1 16 L 2 16 L 3 16 L 3 9 L 2 9 Z M 2 16 L 1 16 C 1 16.796 1.316 17.559 1.879 18.121 L 2.586 17.414 L 3.293 16.707 C 3.105 16.52 3 16.265 3 16 L 2 16 Z M 2.586 17.414 L 1.879 18.121 C 2.441 18.684 3.204 19 4 19 L 4 18 L 4 17 C 3.735 17 3.48 16.895 3.293 16.707 L 2.586 17.414 Z M 4 18 L 4 19 L 14 19 L 14 18 L 14 17 L 4 17 L 4 18 Z M 14 18 L 14 19 C 14.796 19 15.559 18.684 16.121 18.121 L 15.414 17.414 L 14.707 16.707 C 14.52 16.895 14.265 17 14 17 L 14 18 Z M 15.414 17.414 L 16.121 18.121 C 16.684 17.559 17 16.796 17 16 L 16 16 L 15 16 C 15 16.265 14.895 16.52 14.707 16.707 L 15.414 17.414 Z M 16 16 L 17 16 L 17 9 L 16 9 L 15 9 L 15 16 L 16 16 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "IconOutlineGlobe": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 0.055 7 C -0.497 7 -0.945 7.448 -0.945 8 C -0.945 8.552 -0.497 9 0.055 9 L 0.055 8 L 0.055 7 Z M 4 10 L 5 10 L 4 10 Z M 4 11 L 3 11 L 4 11 Z M 6 13 L 6 14 L 6 13 Z M 7 17.945 C 7 18.497 7.448 18.945 8 18.945 C 8.552 18.945 9 18.497 9 17.945 L 8 17.945 L 7 17.945 Z M 6 0.935 C 6 0.383 5.552 -0.065 5 -0.065 C 4.448 -0.065 4 0.383 4 0.935 L 5 0.935 L 6 0.935 Z M 7.5 5 L 7.5 6 L 7.5 5 Z M 16 5 L 16 6 L 16 5 Z M 17.064 6 C 17.616 6 18.064 5.552 18.064 5 C 18.064 4.448 17.616 4 17.064 4 L 17.064 5 L 17.064 6 Z M 11 17.488 C 11 18.04 11.448 18.488 12 18.488 C 12.552 18.488 13 18.04 13 17.488 L 12 17.488 L 11 17.488 Z M 14 13 L 14 14 L 14 13 Z M 17.064 14 C 17.616 14 18.064 13.552 18.064 13 C 18.064 12.448 17.616 12 17.064 12 L 17.064 13 L 17.064 14 Z M 9 0 L 9 1 L 9 0 Z M 0.055 8 L 0.055 9 L 2 9 L 2 8 L 2 7 L 0.055 7 L 0.055 8 Z M 2 8 L 2 9 C 2.265 9 2.52 9.105 2.707 9.293 L 3.414 8.586 L 4.121 7.879 C 3.559 7.316 2.796 7 2 7 L 2 8 Z M 3.414 8.586 L 2.707 9.293 C 2.895 9.48 3 9.735 3 10 L 4 10 L 5 10 C 5 9.204 4.684 8.441 4.121 7.879 L 3.414 8.586 Z M 4 10 L 3 10 L 3 11 L 4 11 L 5 11 L 5 10 L 4 10 Z M 4 11 L 3 11 C 3 11.796 3.316 12.559 3.879 13.121 L 4.586 12.414 L 5.293 11.707 C 5.105 11.52 5 11.265 5 11 L 4 11 Z M 4.586 12.414 L 3.879 13.121 C 4.441 13.684 5.204 14 6 14 L 6 13 L 6 12 C 5.735 12 5.48 11.895 5.293 11.707 L 4.586 12.414 Z M 6 13 L 6 14 C 6.265 14 6.52 14.105 6.707 14.293 L 7.414 13.586 L 8.121 12.879 C 7.559 12.316 6.796 12 6 12 L 6 13 Z M 7.414 13.586 L 6.707 14.293 C 6.895 14.48 7 14.735 7 15 L 8 15 L 9 15 C 9 14.204 8.684 13.441 8.121 12.879 L 7.414 13.586 Z M 8 15 L 7 15 L 7 17.945 L 8 17.945 L 9 17.945 L 9 15 L 8 15 Z M 5 0.935 L 4 0.935 L 4 2.5 L 5 2.5 L 6 2.5 L 6 0.935 L 5 0.935 Z M 5 2.5 L 4 2.5 C 4 3.428 4.369 4.318 5.025 4.975 L 5.732 4.268 L 6.439 3.561 C 6.158 3.279 6 2.898 6 2.5 L 5 2.5 Z M 5.732 4.268 L 5.025 4.975 C 5.682 5.631 6.572 6 7.5 6 L 7.5 5 L 7.5 4 C 7.102 4 6.721 3.842 6.439 3.561 L 5.732 4.268 Z M 7.5 5 L 7.5 6 L 8 6 L 8 5 L 8 4 L 7.5 4 L 7.5 5 Z M 8 5 L 8 6 C 8.265 6 8.52 6.105 8.707 6.293 L 9.414 5.586 L 10.121 4.879 C 9.559 4.316 8.796 4 8 4 L 8 5 Z M 9.414 5.586 L 8.707 6.293 C 8.895 6.48 9 6.735 9 7 L 10 7 L 11 7 C 11 6.204 10.684 5.441 10.121 4.879 L 9.414 5.586 Z M 10 7 L 9 7 C 9 7.796 9.316 8.559 9.879 9.121 L 10.586 8.414 L 11.293 7.707 C 11.105 7.52 11 7.265 11 7 L 10 7 Z M 10.586 8.414 L 9.879 9.121 C 10.441 9.684 11.204 10 12 10 L 12 9 L 12 8 C 11.735 8 11.48 7.895 11.293 7.707 L 10.586 8.414 Z M 12 9 L 12 10 C 12.796 10 13.559 9.684 14.121 9.121 L 13.414 8.414 L 12.707 7.707 C 12.52 7.895 12.265 8 12 8 L 12 9 Z M 13.414 8.414 L 14.121 9.121 C 14.684 8.559 15 7.796 15 7 L 14 7 L 13 7 C 13 7.265 12.895 7.52 12.707 7.707 L 13.414 8.414 Z M 14 7 L 15 7 C 15 6.735 15.105 6.48 15.293 6.293 L 14.586 5.586 L 13.879 4.879 C 13.316 5.441 13 6.204 13 7 L 14 7 Z M 14.586 5.586 L 15.293 6.293 C 15.48 6.105 15.735 6 16 6 L 16 5 L 16 4 C 15.204 4 14.441 4.316 13.879 4.879 L 14.586 5.586 Z M 16 5 L 16 6 L 17.064 6 L 17.064 5 L 17.064 4 L 16 4 L 16 5 Z M 12 17.488 L 13 17.488 L 13 15 L 12 15 L 11 15 L 11 17.488 L 12 17.488 Z M 12 15 L 13 15 C 13 14.735 13.105 14.48 13.293 14.293 L 12.586 13.586 L 11.879 12.879 C 11.316 13.441 11 14.204 11 15 L 12 15 Z M 12.586 13.586 L 13.293 14.293 C 13.48 14.105 13.735 14 14 14 L 14 13 L 14 12 C 13.204 12 12.441 12.316 11.879 12.879 L 12.586 13.586 Z M 14 13 L 14 14 L 17.064 14 L 17.064 13 L 17.064 12 L 14 12 L 14 13 Z M 18 9 L 17 9 C 17 10.051 16.793 11.091 16.391 12.061 L 17.315 12.444 L 18.239 12.827 C 18.741 11.614 19 10.313 19 9 L 18 9 Z M 17.315 12.444 L 16.391 12.061 C 15.989 13.032 15.4 13.914 14.657 14.657 L 15.364 15.364 L 16.071 16.071 C 17 15.142 17.736 14.04 18.239 12.827 L 17.315 12.444 Z M 15.364 15.364 L 14.657 14.657 C 13.914 15.4 13.032 15.989 12.061 16.391 L 12.444 17.315 L 12.827 18.239 C 14.04 17.736 15.142 17 16.071 16.071 L 15.364 15.364 Z M 12.444 17.315 L 12.061 16.391 C 11.091 16.793 10.051 17 9 17 L 9 18 L 9 19 C 10.313 19 11.614 18.741 12.827 18.239 L 12.444 17.315 Z M 9 18 L 9 17 C 7.949 17 6.909 16.793 5.939 16.391 L 5.556 17.315 L 5.173 18.239 C 6.386 18.741 7.687 19 9 19 L 9 18 Z M 5.556 17.315 L 5.939 16.391 C 4.968 15.989 4.086 15.4 3.343 14.657 L 2.636 15.364 L 1.929 16.071 C 2.858 17 3.96 17.736 5.173 18.239 L 5.556 17.315 Z M 2.636 15.364 L 3.343 14.657 C 2.6 13.914 2.011 13.032 1.609 12.061 L 0.685 12.444 L -0.239 12.827 C 0.264 14.04 1 15.142 1.929 16.071 L 2.636 15.364 Z M 0.685 12.444 L 1.609 12.061 C 1.207 11.091 1 10.051 1 9 L 0 9 L -1 9 C -1 10.313 -0.741 11.614 -0.239 12.827 L 0.685 12.444 Z M 0 9 L 1 9 C 1 6.878 1.843 4.843 3.343 3.343 L 2.636 2.636 L 1.929 1.929 C 0.054 3.804 -1 6.348 -1 9 L 0 9 Z M 2.636 2.636 L 3.343 3.343 C 4.843 1.843 6.878 1 9 1 L 9 0 L 9 -1 C 6.348 -1 3.804 0.054 1.929 1.929 L 2.636 2.636 Z M 9 0 L 9 1 C 11.122 1 13.157 1.843 14.657 3.343 L 15.364 2.636 L 16.071 1.929 C 14.196 0.054 11.652 -1 9 -1 L 9 0 Z M 15.364 2.636 L 14.657 3.343 C 16.157 4.843 17 6.878 17 9 L 18 9 L 19 9 C 19 6.348 17.946 3.804 16.071 1.929 L 15.364 2.636 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "IconOutlineHeart": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 1.318 1.318 L 2.025 2.025 L 2.025 2.025 L 1.318 1.318 Z M 1.318 7.682 L 2.025 6.975 L 2.025 6.975 L 1.318 7.682 Z M 9 15.364 L 8.293 16.071 C 8.48 16.259 8.735 16.364 9 16.364 C 9.265 16.364 9.52 16.259 9.707 16.071 L 9 15.364 Z M 16.682 7.682 L 15.975 6.975 L 15.975 6.975 L 16.682 7.682 Z M 18 4.5 L 17 4.5 L 18 4.5 Z M 10.318 1.318 L 9.611 0.611 L 9.611 0.611 L 10.318 1.318 Z M 9 2.636 L 8.293 3.343 C 8.48 3.531 8.735 3.636 9 3.636 C 9.265 3.636 9.52 3.531 9.707 3.343 L 9 2.636 Z M 7.682 1.318 L 6.975 2.025 L 6.975 2.025 L 7.682 1.318 Z M 4.5 0 L 4.5 -1 L 4.5 0 Z M 1.318 1.318 L 0.611 0.611 C 0.1 1.122 -0.305 1.728 -0.581 2.395 L 0.343 2.778 L 1.266 3.161 C 1.442 2.736 1.7 2.35 2.025 2.025 L 1.318 1.318 Z M 0.343 2.778 L -0.581 2.395 C -0.858 3.063 -1 3.778 -1 4.5 L 0 4.5 L 1 4.5 C 1 4.04 1.091 3.585 1.266 3.161 L 0.343 2.778 Z M 0 4.5 L -1 4.5 C -1 5.222 -0.858 5.938 -0.581 6.605 L 0.343 6.222 L 1.266 5.839 C 1.091 5.415 1 4.96 1 4.5 L 0 4.5 Z M 0.343 6.222 L -0.581 6.605 C -0.305 7.272 0.1 7.878 0.611 8.389 L 1.318 7.682 L 2.025 6.975 C 1.7 6.65 1.442 6.264 1.266 5.839 L 0.343 6.222 Z M 1.318 7.682 L 0.611 8.389 L 8.293 16.071 L 9 15.364 L 9.707 14.657 L 2.025 6.975 L 1.318 7.682 Z M 9 15.364 L 9.707 16.071 L 17.389 8.389 L 16.682 7.682 L 15.975 6.975 L 8.293 14.657 L 9 15.364 Z M 16.682 7.682 L 17.389 8.389 C 18.421 7.358 19 5.959 19 4.5 L 18 4.5 L 17 4.5 C 17 5.428 16.631 6.319 15.975 6.975 L 16.682 7.682 Z M 18 4.5 L 19 4.5 C 19 3.041 18.421 1.642 17.389 0.611 L 16.682 1.318 L 15.975 2.025 C 16.631 2.682 17 3.572 17 4.5 L 18 4.5 Z M 16.682 1.318 L 17.389 0.611 C 16.358 -0.421 14.959 -1 13.5 -1 L 13.5 0 L 13.5 1 C 14.428 1 15.319 1.369 15.975 2.025 L 16.682 1.318 Z M 13.5 0 L 13.5 -1 C 12.041 -1 10.642 -0.421 9.611 0.611 L 10.318 1.318 L 11.025 2.025 C 11.682 1.369 12.572 1 13.5 1 L 13.5 0 Z M 10.318 1.318 L 9.611 0.611 L 8.293 1.929 L 9 2.636 L 9.707 3.343 L 11.025 2.025 L 10.318 1.318 Z M 9 2.636 L 9.707 1.929 L 8.389 0.611 L 7.682 1.318 L 6.975 2.025 L 8.293 3.343 L 9 2.636 Z M 7.682 1.318 L 8.389 0.611 C 7.878 0.1 7.272 -0.305 6.605 -0.581 L 6.222 0.343 L 5.839 1.266 C 6.264 1.442 6.65 1.7 6.975 2.025 L 7.682 1.318 Z M 6.222 0.343 L 6.605 -0.581 C 5.938 -0.858 5.222 -1 4.5 -1 L 4.5 0 L 4.5 1 C 4.96 1 5.415 1.091 5.839 1.266 L 6.222 0.343 Z M 4.5 0 L 4.5 -1 C 3.778 -1 3.063 -0.858 2.395 -0.581 L 2.778 0.343 L 3.161 1.266 C 3.585 1.091 4.04 1 4.5 1 L 4.5 0 Z M 2.778 0.343 L 2.395 -0.581 C 1.728 -0.305 1.122 0.1 0.611 0.611 L 1.318 1.318 L 2.025 2.025 C 2.35 1.7 2.736 1.442 3.161 1.266 L 2.778 0.343 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
  },
  "IconOutlineLocationMarker": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 13.657 13.657 M 9.414 17.9 L 8.707 17.193 L 8.707 17.193 L 9.414 17.9 Z M 8.001 18.486 L 8.001 19.486 L 8.001 18.486 Z M 6.587 17.9 L 7.294 17.193 L 7.294 17.193 L 6.587 17.9 Z M 2.343 13.657 L 1.636 14.364 L 1.636 14.364 L 2.343 13.657 Z M 13.657 13.657 M 13.657 13.657 L 12.95 12.95 L 8.707 17.193 L 9.414 17.9 L 10.121 18.607 L 14.364 14.364 L 13.657 13.657 Z M 9.414 17.9 L 8.707 17.193 C 8.614 17.286 8.504 17.359 8.383 17.41 L 8.766 18.333 L 9.148 19.257 C 9.512 19.106 9.843 18.885 10.121 18.606 L 9.414 17.9 Z M 8.766 18.333 L 8.383 17.41 C 8.262 17.46 8.132 17.486 8.001 17.486 L 8.001 18.486 L 8.001 19.486 C 8.394 19.486 8.785 19.408 9.148 19.257 L 8.766 18.333 Z M 8.001 18.486 L 8.001 17.486 C 7.869 17.486 7.74 17.46 7.618 17.41 L 7.235 18.333 L 6.853 19.257 C 7.216 19.408 7.607 19.486 8.001 19.486 L 8.001 18.486 Z M 7.235 18.333 L 7.618 17.41 C 7.497 17.359 7.387 17.286 7.294 17.193 L 6.587 17.9 L 5.88 18.606 C 6.158 18.885 6.489 19.106 6.853 19.257 L 7.235 18.333 Z M 6.587 17.9 L 7.294 17.193 L 3.05 12.95 L 2.343 13.657 L 1.636 14.364 L 5.88 18.607 L 6.587 17.9 Z M 2.343 13.657 L 3.05 12.95 C 2.071 11.971 1.405 10.723 1.134 9.365 L 0.154 9.561 L -0.827 9.756 C -0.48 11.501 0.377 13.105 1.636 14.364 L 2.343 13.657 Z M 0.154 9.561 L 1.134 9.365 C 0.864 8.008 1.003 6.6 1.533 5.321 L 0.609 4.938 L -0.315 4.556 C -0.996 6.2 -1.174 8.01 -0.827 9.756 L 0.154 9.561 Z M 0.609 4.938 L 1.533 5.321 C 2.063 4.042 2.96 2.949 4.111 2.18 L 3.555 1.348 L 3 0.517 C 1.52 1.506 0.366 2.911 -0.315 4.556 L 0.609 4.938 Z M 3.555 1.348 L 4.111 2.18 C 5.262 1.411 6.616 1 8 1 L 8 0 L 8 -1 C 6.22 -1 4.48 -0.472 3 0.517 L 3.555 1.348 Z M 8 0 L 8 1 C 9.384 1 10.738 1.411 11.889 2.18 L 12.445 1.348 L 13 0.517 C 11.52 -0.472 9.78 -1 8 -1 L 8 0 Z M 12.445 1.348 L 11.889 2.18 C 13.04 2.949 13.937 4.042 14.467 5.321 L 15.391 4.938 L 16.315 4.556 C 15.634 2.911 14.48 1.506 13 0.517 L 12.445 1.348 Z M 15.391 4.938 L 14.467 5.321 C 14.997 6.6 15.136 8.008 14.866 9.365 L 15.846 9.561 L 16.827 9.756 C 17.174 8.01 16.996 6.2 16.315 4.556 L 15.391 4.938 Z M 15.846 9.561 L 14.866 9.365 C 14.595 10.723 13.929 11.971 12.95 12.95 L 13.657 13.657 L 14.364 14.364 C 15.623 13.105 16.48 11.501 16.827 9.756 L 15.846 9.561 Z M 13.657 13.657\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 3.000)\"/><path d=\"M 6 3 L 7 3 L 6 3 Z M 3 0 L 3 -1 L 3 0 Z M 6 3 L 5 3 C 5 3.53 4.789 4.039 4.414 4.414 L 5.121 5.121 L 5.828 5.828 C 6.579 5.078 7 4.061 7 3 L 6 3 Z M 5.121 5.121 L 4.414 4.414 C 4.039 4.789 3.53 5 3 5 L 3 6 L 3 7 C 4.061 7 5.078 6.579 5.828 5.828 L 5.121 5.121 Z M 3 6 L 3 5 C 2.47 5 1.961 4.789 1.586 4.414 L 0.879 5.121 L 0.172 5.828 C 0.922 6.579 1.939 7 3 7 L 3 6 Z M 0.879 5.121 L 1.586 4.414 C 1.211 4.039 1 3.53 1 3 L 0 3 L -1 3 C -1 4.061 -0.579 5.078 0.172 5.828 L 0.879 5.121 Z M 0 3 L 1 3 C 1 2.47 1.211 1.961 1.586 1.586 L 0.879 0.879 L 0.172 0.172 C -0.579 0.922 -1 1.939 -1 3 L 0 3 Z M 0.879 0.879 L 1.586 1.586 C 1.961 1.211 2.47 1 3 1 L 3 0 L 3 -1 C 1.939 -1 0.922 -0.579 0.172 0.172 L 0.879 0.879 Z M 3 0 L 3 1 C 3.53 1 4.039 1.211 4.414 1.586 L 5.121 0.879 L 5.828 0.172 C 5.078 -0.579 4.061 -1 3 -1 L 3 0 Z M 5.121 0.879 L 4.414 1.586 C 4.789 1.961 5 2.47 5 3 L 6 3 L 7 3 C 7 1.939 6.579 0.922 5.828 0.172 L 5.121 0.879 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 9 8)\"/>"
  },
  "IconOutlineMail": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 0.555 2.168 C 0.095 1.862 -0.526 1.986 -0.832 2.445 C -1.138 2.905 -1.014 3.526 -0.555 3.832 L 0 3 L 0.555 2.168 Z M 7.89 8.26 L 8.445 7.428 L 8.445 7.428 L 7.89 8.26 Z M 10.11 8.26 L 9.555 7.428 L 9.555 7.428 L 10.11 8.26 Z M 18.555 3.832 C 19.014 3.526 19.138 2.905 18.832 2.445 C 18.526 1.986 17.905 1.862 17.445 2.168 L 18 3 L 18.555 3.832 Z M 16 0 L 16 -1 L 16 0 Z M 2 0 L 2 -1 L 2 0 Z M 0 2 L -1 2 L 0 2 Z M 0 12 L -1 12 L 0 12 Z M 0 3 L -0.555 3.832 L 7.335 9.092 L 7.89 8.26 L 8.445 7.428 L 0.555 2.168 L 0 3 Z M 7.89 8.26 L 7.335 9.092 C 7.828 9.421 8.407 9.596 9 9.596 L 9 8.596 L 9 7.596 C 8.802 7.596 8.609 7.538 8.445 7.428 L 7.89 8.26 Z M 9 8.596 L 9 9.596 C 9.593 9.596 10.172 9.421 10.665 9.092 L 10.11 8.26 L 9.555 7.428 C 9.391 7.538 9.198 7.596 9 7.596 L 9 8.596 Z M 10.11 8.26 L 10.665 9.092 L 18.555 3.832 L 18 3 L 17.445 2.168 L 9.555 7.428 L 10.11 8.26 Z M 2 14 L 2 15 L 16 15 L 16 14 L 16 13 L 2 13 L 2 14 Z M 16 14 L 16 15 C 16.796 15 17.559 14.684 18.121 14.121 L 17.414 13.414 L 16.707 12.707 C 16.52 12.895 16.265 13 16 13 L 16 14 Z M 17.414 13.414 L 18.121 14.121 C 18.684 13.559 19 12.796 19 12 L 18 12 L 17 12 C 17 12.265 16.895 12.52 16.707 12.707 L 17.414 13.414 Z M 18 12 L 19 12 L 19 2 L 18 2 L 17 2 L 17 12 L 18 12 Z M 18 2 L 19 2 C 19 1.204 18.684 0.441 18.121 -0.121 L 17.414 0.586 L 16.707 1.293 C 16.895 1.48 17 1.735 17 2 L 18 2 Z M 17.414 0.586 L 18.121 -0.121 C 17.559 -0.684 16.796 -1 16 -1 L 16 0 L 16 1 C 16.265 1 16.52 1.105 16.707 1.293 L 17.414 0.586 Z M 16 0 L 16 -1 L 2 -1 L 2 0 L 2 1 L 16 1 L 16 0 Z M 2 0 L 2 -1 C 1.204 -1 0.441 -0.684 -0.121 -0.121 L 0.586 0.586 L 1.293 1.293 C 1.48 1.105 1.735 1 2 1 L 2 0 Z M 0.586 0.586 L -0.121 -0.121 C -0.684 0.441 -1 1.204 -1 2 L 0 2 L 1 2 C 1 1.735 1.105 1.48 1.293 1.293 L 0.586 0.586 Z M 0 2 L -1 2 L -1 12 L 0 12 L 1 12 L 1 2 L 0 2 Z M 0 12 L -1 12 C -1 12.796 -0.684 13.559 -0.121 14.121 L 0.586 13.414 L 1.293 12.707 C 1.105 12.52 1 12.265 1 12 L 0 12 Z M 0.586 13.414 L -0.121 14.121 C 0.441 14.684 1.204 15 2 15 L 2 14 L 2 13 C 1.735 13 1.48 12.895 1.293 12.707 L 0.586 13.414 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
  },
  "IconOutlineMenu": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 0 -1 C -0.552 -1 -1 -0.552 -1 0 C -1 0.552 -0.552 1 0 1 L 0 0 L 0 -1 Z M 16 1 C 16.552 1 17 0.552 17 0 C 17 -0.552 16.552 -1 16 -1 L 16 0 L 16 1 Z M 0 5 C -0.552 5 -1 5.448 -1 6 C -1 6.552 -0.552 7 0 7 L 0 6 L 0 5 Z M 16 7 C 16.552 7 17 6.552 17 6 C 17 5.448 16.552 5 16 5 L 16 6 L 16 7 Z M 0 11 C -0.552 11 -1 11.448 -1 12 C -1 12.552 -0.552 13 0 13 L 0 12 L 0 11 Z M 16 13 C 16.552 13 17 12.552 17 12 C 17 11.448 16.552 11 16 11 L 16 12 L 16 13 Z M 0 0 L 0 1 L 16 1 L 16 0 L 16 -1 L 0 -1 L 0 0 Z M 16 0 L 16 -1 L 0 -1 L 0 0 L 0 1 L 16 1 L 16 0 Z M 0 6 L 0 7 L 16 7 L 16 6 L 16 5 L 0 5 L 0 6 Z M 16 6 L 16 5 L 0 5 L 0 6 L 0 7 L 16 7 L 16 6 Z M 0 12 L 0 13 L 16 13 L 16 12 L 16 11 L 0 11 L 0 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 6)\"/>"
  },
  "IconOutlineMinus": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 12 1 C 12.552 1 13 0.552 13 0 C 13 -0.552 12.552 -1 12 -1 L 12 0 L 12 1 Z M 0 -1 C -0.552 -1 -1 -0.552 -1 0 C -1 0.552 -0.552 1 0 1 L 0 0 L 0 -1 Z M 12 0 L 12 -1 L 0 -1 L 0 0 L 0 1 L 12 1 L 12 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 12)\"/>"
  },
  "IconOutlinePlay": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 4.752 2.3 L 4.197 3.132 L 4.197 3.132 L 4.752 2.3 Z M 1.555 0.168 L 1 1 L 1 1 L 1.555 0.168 Z M 0 1.002 L 1 1.002 L 1 1 L 0 1.002 Z M 0 5.265 L 1 5.265 L 1 5.265 L 0 5.265 Z M 1.555 6.097 L 1 5.265 L 1 5.265 L 1.555 6.097 Z M 4.752 3.965 L 4.197 3.133 L 4.197 3.133 L 4.752 3.965 Z M 4.752 2.3 L 5.307 1.468 L 2.11 -0.664 L 1.555 0.168 L 1 1 L 4.197 3.132 L 4.752 2.3 Z M 1.555 0.168 L 2.11 -0.664 C 1.809 -0.865 1.458 -0.98 1.096 -0.998 L 1.048 0.001 L 1 1 L 1 1 L 1.555 0.168 Z M 1.048 0.001 L 1.096 -0.998 C 0.734 -1.015 0.374 -0.934 0.055 -0.763 L 0.527 0.119 L 1 1 L 1 1 L 1.048 0.001 Z M 0.527 0.119 L 0.055 -0.763 C -0.265 -0.591 -0.532 -0.336 -0.717 -0.025 L 0.141 0.487 L 1 1 L 1 1 L 0.527 0.119 Z M 0.141 0.487 L -0.717 -0.025 C -0.903 0.286 -1.001 0.642 -1 1.004 L 0 1.002 L 1 1 L 1 1 L 0.141 0.487 Z M 0 1.002 L -1 1.002 L -1 5.265 L 0 5.265 L 1 5.265 L 1 1.002 L 0 1.002 Z M 0 5.265 L -1 5.265 C -1 5.627 -0.902 5.982 -0.716 6.293 L 0.142 5.779 L 1 5.265 L 1 5.265 L 0 5.265 Z M 0.142 5.779 L -0.716 6.293 C -0.53 6.604 -0.263 6.858 0.056 7.029 L 0.528 6.147 L 1 5.265 L 1 5.265 L 0.142 5.779 Z M 0.528 6.147 L 0.056 7.029 C 0.376 7.2 0.735 7.281 1.097 7.263 L 1.049 6.264 L 1 5.265 L 1 5.265 L 0.528 6.147 Z M 1.049 6.264 L 1.097 7.263 C 1.459 7.245 1.809 7.13 2.11 6.929 L 1.555 6.097 L 1 5.265 L 1 5.265 L 1.049 6.264 Z M 1.555 6.097 L 2.11 6.929 L 5.307 4.797 L 4.752 3.965 L 4.197 3.133 L 1 5.265 L 1.555 6.097 Z M 4.752 3.965 L 5.307 4.797 C 5.581 4.615 5.805 4.367 5.961 4.077 L 5.079 3.605 L 4.197 3.133 L 4.197 3.133 L 4.752 3.965 Z M 5.079 3.605 L 5.961 4.077 C 6.116 3.787 6.197 3.462 6.197 3.133 L 5.197 3.133 L 4.197 3.133 L 4.197 3.133 L 5.079 3.605 Z M 5.197 3.133 L 6.197 3.133 C 6.197 2.804 6.116 2.48 5.961 2.19 L 5.079 2.661 L 4.197 3.133 L 4.197 3.133 L 5.197 3.133 Z M 5.079 2.661 L 5.961 2.19 C 5.807 1.902 5.583 1.652 5.307 1.468 L 4.752 2.3 L 4.197 3.132 C 4.195 3.131 4.196 3.131 4.197 3.133 L 5.079 2.661 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 10 8.868)\"/><path d=\"M 9 0 L 9 1 L 9 0 Z M 18 9 L 17 9 C 17 10.051 16.793 11.091 16.391 12.061 L 17.315 12.444 L 18.239 12.827 C 18.741 11.614 19 10.313 19 9 L 18 9 Z M 17.315 12.444 L 16.391 12.061 C 15.989 13.032 15.4 13.914 14.657 14.657 L 15.364 15.364 L 16.071 16.071 C 17 15.142 17.736 14.04 18.239 12.827 L 17.315 12.444 Z M 15.364 15.364 L 14.657 14.657 C 13.914 15.4 13.032 15.989 12.061 16.391 L 12.444 17.315 L 12.827 18.239 C 14.04 17.736 15.142 17 16.071 16.071 L 15.364 15.364 Z M 12.444 17.315 L 12.061 16.391 C 11.091 16.793 10.051 17 9 17 L 9 18 L 9 19 C 10.313 19 11.614 18.741 12.827 18.239 L 12.444 17.315 Z M 9 18 L 9 17 C 7.949 17 6.909 16.793 5.939 16.391 L 5.556 17.315 L 5.173 18.239 C 6.386 18.741 7.687 19 9 19 L 9 18 Z M 5.556 17.315 L 5.939 16.391 C 4.968 15.989 4.086 15.4 3.343 14.657 L 2.636 15.364 L 1.929 16.071 C 2.858 17 3.96 17.736 5.173 18.239 L 5.556 17.315 Z M 2.636 15.364 L 3.343 14.657 C 2.6 13.914 2.011 13.032 1.609 12.061 L 0.685 12.444 L -0.239 12.827 C 0.264 14.04 1 15.142 1.929 16.071 L 2.636 15.364 Z M 0.685 12.444 L 1.609 12.061 C 1.207 11.091 1 10.051 1 9 L 0 9 L -1 9 C -1 10.313 -0.741 11.614 -0.239 12.827 L 0.685 12.444 Z M 0 9 L 1 9 C 1 6.878 1.843 4.843 3.343 3.343 L 2.636 2.636 L 1.929 1.929 C 0.054 3.804 -1 6.348 -1 9 L 0 9 Z M 2.636 2.636 L 3.343 3.343 C 4.843 1.843 6.878 1 9 1 L 9 0 L 9 -1 C 6.348 -1 3.804 0.054 1.929 1.929 L 2.636 2.636 Z M 9 0 L 9 1 C 11.122 1 13.157 1.843 14.657 3.343 L 15.364 2.636 L 16.071 1.929 C 14.196 0.054 11.652 -1 9 -1 L 9 0 Z M 15.364 2.636 L 14.657 3.343 C 16.157 4.843 17 6.878 17 9 L 18 9 L 19 9 C 19 6.348 17.946 3.804 16.071 1.929 L 15.364 2.636 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "IconOutlinePlus": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 7 0 C 7 -0.552 6.552 -1 6 -1 C 5.448 -1 5 -0.552 5 0 L 6 0 L 7 0 Z M 5 12 C 5 12.552 5.448 13 6 13 C 6.552 13 7 12.552 7 12 L 6 12 L 5 12 Z M 12 7 C 12.552 7 13 6.552 13 6 C 13 5.448 12.552 5 12 5 L 12 6 L 12 7 Z M 0 5 C -0.552 5 -1 5.448 -1 6 C -1 6.552 -0.552 7 0 7 L 0 6 L 0 5 Z M 6 0 L 5 0 L 5 6 L 6 6 L 7 6 L 7 0 L 6 0 Z M 6 6 L 5 6 L 5 12 L 6 12 L 7 12 L 7 6 L 6 6 Z M 6 6 L 6 7 L 12 7 L 12 6 L 12 5 L 6 5 L 6 6 Z M 6 6 L 6 5 L 0 5 L 0 6 L 0 7 L 6 7 L 6 6 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
  },
  "IconOutlineSearch": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 17.293 18.707 C 17.683 19.098 18.317 19.098 18.707 18.707 C 19.098 18.317 19.098 17.683 18.707 17.293 L 18 18 L 17.293 18.707 Z M 12.707 11.293 C 12.317 10.902 11.683 10.902 11.293 11.293 C 10.902 11.683 10.902 12.317 11.293 12.707 L 12 12 L 12.707 11.293 Z M 7 14 L 7 15 L 7 14 Z M 0 7 L -1 7 L 0 7 Z M 7 0 L 7 1 L 7 0 Z M 18 18 L 18.707 17.293 L 12.707 11.293 L 12 12 L 11.293 12.707 L 17.293 18.707 L 18 18 Z M 14 7 L 13 7 C 13 7.788 12.845 8.568 12.543 9.296 L 13.467 9.679 L 14.391 10.061 C 14.793 9.091 15 8.051 15 7 L 14 7 Z M 13.467 9.679 L 12.543 9.296 C 12.242 10.024 11.8 10.685 11.243 11.243 L 11.95 11.95 L 12.657 12.657 C 13.4 11.914 13.989 11.032 14.391 10.061 L 13.467 9.679 Z M 11.95 11.95 L 11.243 11.243 C 10.685 11.8 10.024 12.242 9.296 12.543 L 9.679 13.467 L 10.061 14.391 C 11.032 13.989 11.914 13.4 12.657 12.657 L 11.95 11.95 Z M 9.679 13.467 L 9.296 12.543 C 8.568 12.845 7.788 13 7 13 L 7 14 L 7 15 C 8.051 15 9.091 14.793 10.061 14.391 L 9.679 13.467 Z M 7 14 L 7 13 C 6.212 13 5.432 12.845 4.704 12.543 L 4.321 13.467 L 3.939 14.391 C 4.909 14.793 5.949 15 7 15 L 7 14 Z M 4.321 13.467 L 4.704 12.543 C 3.976 12.242 3.315 11.8 2.757 11.243 L 2.05 11.95 L 1.343 12.657 C 2.086 13.4 2.968 13.989 3.939 14.391 L 4.321 13.467 Z M 2.05 11.95 L 2.757 11.243 C 2.2 10.685 1.758 10.024 1.457 9.296 L 0.533 9.679 L -0.391 10.061 C 0.011 11.032 0.6 11.914 1.343 12.657 L 2.05 11.95 Z M 0.533 9.679 L 1.457 9.296 C 1.155 8.568 1 7.788 1 7 L 0 7 L -1 7 C -1 8.051 -0.793 9.091 -0.391 10.061 L 0.533 9.679 Z M 0 7 L 1 7 C 1 5.409 1.632 3.883 2.757 2.757 L 2.05 2.05 L 1.343 1.343 C -0.157 2.843 -1 4.878 -1 7 L 0 7 Z M 2.05 2.05 L 2.757 2.757 C 3.883 1.632 5.409 1 7 1 L 7 0 L 7 -1 C 4.878 -1 2.843 -0.157 1.343 1.343 L 2.05 2.05 Z M 7 0 L 7 1 C 8.591 1 10.117 1.632 11.243 2.757 L 11.95 2.05 L 12.657 1.343 C 11.157 -0.157 9.122 -1 7 -1 L 7 0 Z M 11.95 2.05 L 11.243 2.757 C 12.368 3.883 13 5.409 13 7 L 14 7 L 15 7 C 15 4.878 14.157 2.843 12.657 1.343 L 11.95 2.05 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "IconOutlineShoppingBag": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 11 8 C 11 8.552 11.448 9 12 9 C 12.552 9 13 8.552 13 8 L 12 8 L 11 8 Z M 12 4 L 13 4 L 12 4 Z M 8 0 L 8 -1 L 8 0 Z M 4 4 L 3 4 L 4 4 Z M 3 8 C 3 8.552 3.448 9 4 9 C 4.552 9 5 8.552 5 8 L 4 8 L 3 8 Z M 1 6 L 1 5 C 0.48 5 0.047 5.399 0.003 5.917 L 1 6 Z M 15 6 L 15.997 5.917 C 15.953 5.399 15.52 5 15 5 L 15 6 Z M 16 18 L 16 19 C 16.28 19 16.547 18.883 16.736 18.677 C 16.925 18.471 17.02 18.196 16.997 17.917 L 16 18 Z M 0 18 L -0.997 17.917 C -1.02 18.196 -0.925 18.471 -0.736 18.677 C -0.547 18.883 -0.28 19 0 19 L 0 18 Z M 12 8 L 13 8 L 13 4 L 12 4 L 11 4 L 11 8 L 12 8 Z M 12 4 L 13 4 C 13 2.674 12.473 1.402 11.536 0.464 L 10.828 1.172 L 10.121 1.879 C 10.684 2.441 11 3.204 11 4 L 12 4 Z M 10.828 1.172 L 11.536 0.464 C 10.598 -0.473 9.326 -1 8 -1 L 8 0 L 8 1 C 8.796 1 9.559 1.316 10.121 1.879 L 10.828 1.172 Z M 8 0 L 8 -1 C 6.674 -1 5.402 -0.473 4.464 0.464 L 5.172 1.172 L 5.879 1.879 C 6.441 1.316 7.204 1 8 1 L 8 0 Z M 5.172 1.172 L 4.464 0.464 C 3.527 1.402 3 2.674 3 4 L 4 4 L 5 4 C 5 3.204 5.316 2.441 5.879 1.879 L 5.172 1.172 Z M 4 4 L 3 4 L 3 8 L 4 8 L 5 8 L 5 4 L 4 4 Z M 1 6 L 1 7 L 15 7 L 15 6 L 15 5 L 1 5 L 1 6 Z M 15 6 L 14.003 6.083 L 15.003 18.083 L 16 18 L 16.997 17.917 L 15.997 5.917 L 15 6 Z M 16 18 L 16 17 L 0 17 L 0 18 L 0 19 L 16 19 L 16 18 Z M 0 18 L 0.997 18.083 L 1.997 6.083 L 1 6 L 0.003 5.917 L -0.997 17.917 L 0 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 3)\"/>"
  },
  "IconOutlineShoppingCart": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 0 -1 C -0.552 -1 -1 -0.552 -1 0 C -1 0.552 -0.552 1 0 1 L 0 0 L 0 -1 Z M 2 0 L 2.981 -0.196 C 2.887 -0.664 2.477 -1 2 -1 L 2 0 Z M 14 10 L 14 11 C 14.379 11 14.725 10.786 14.894 10.447 L 14 10 Z M 18 2 L 18.894 2.447 C 19.049 2.137 19.033 1.769 18.851 1.474 C 18.668 1.179 18.347 1 18 1 L 18 2 Z M 6 16 L 5 16 L 6 16 Z M 2 16 L 1 16 L 2 16 Z M 0 0 L 0 1 L 2 1 L 2 0 L 2 -1 L 0 -1 L 0 0 Z M 2 0 L 1.019 0.196 L 1.419 2.196 L 2.4 2 L 3.381 1.804 L 2.981 -0.196 L 2 0 Z M 4 10 L 4 11 L 14 11 L 14 10 L 14 9 L 4 9 L 4 10 Z M 14 10 L 14.894 10.447 L 18.894 2.447 L 18 2 L 17.106 1.553 L 13.106 9.553 L 14 10 Z M 18 2 L 18 1 L 2.4 1 L 2.4 2 L 2.4 3 L 18 3 L 18 2 Z M 2.4 2 L 1.419 2.196 L 3.019 10.196 L 4 10 L 4.981 9.804 L 3.381 1.804 L 2.4 2 Z M 4 10 L 3.293 9.293 L 1 11.586 L 1.707 12.293 L 2.414 13 L 4.707 10.707 L 4 10 Z M 1.707 12.293 L 1 11.586 C -0.26 12.846 0.632 15 2.414 15 L 2.414 14 L 2.414 13 L 2.414 13 L 1.707 12.293 Z M 2.414 14 L 2.414 15 L 14 15 L 14 14 L 14 13 L 2.414 13 L 2.414 14 Z M 14 14 L 14 13 C 13.204 13 12.441 13.316 11.879 13.879 L 12.586 14.586 L 13.293 15.293 C 13.48 15.105 13.735 15 14 15 L 14 14 Z M 12.586 14.586 L 11.879 13.879 C 11.316 14.441 11 15.204 11 16 L 12 16 L 13 16 C 13 15.735 13.105 15.48 13.293 15.293 L 12.586 14.586 Z M 12 16 L 11 16 C 11 16.796 11.316 17.559 11.879 18.121 L 12.586 17.414 L 13.293 16.707 C 13.105 16.52 13 16.265 13 16 L 12 16 Z M 12.586 17.414 L 11.879 18.121 C 12.441 18.684 13.204 19 14 19 L 14 18 L 14 17 C 13.735 17 13.48 16.895 13.293 16.707 L 12.586 17.414 Z M 14 18 L 14 19 C 14.796 19 15.559 18.684 16.121 18.121 L 15.414 17.414 L 14.707 16.707 C 14.52 16.895 14.265 17 14 17 L 14 18 Z M 15.414 17.414 L 16.121 18.121 C 16.684 17.559 17 16.796 17 16 L 16 16 L 15 16 C 15 16.265 14.895 16.52 14.707 16.707 L 15.414 17.414 Z M 16 16 L 17 16 C 17 15.204 16.684 14.441 16.121 13.879 L 15.414 14.586 L 14.707 15.293 C 14.895 15.48 15 15.735 15 16 L 16 16 Z M 15.414 14.586 L 16.121 13.879 C 15.559 13.316 14.796 13 14 13 L 14 14 L 14 15 C 14.265 15 14.52 15.105 14.707 15.293 L 15.414 14.586 Z M 6 16 L 5 16 C 5 16.265 4.895 16.52 4.707 16.707 L 5.414 17.414 L 6.121 18.121 C 6.684 17.559 7 16.796 7 16 L 6 16 Z M 5.414 17.414 L 4.707 16.707 C 4.52 16.895 4.265 17 4 17 L 4 18 L 4 19 C 4.796 19 5.559 18.684 6.121 18.121 L 5.414 17.414 Z M 4 18 L 4 17 C 3.735 17 3.48 16.895 3.293 16.707 L 2.586 17.414 L 1.879 18.121 C 2.441 18.684 3.204 19 4 19 L 4 18 Z M 2.586 17.414 L 3.293 16.707 C 3.105 16.52 3 16.265 3 16 L 2 16 L 1 16 C 1 16.796 1.316 17.559 1.879 18.121 L 2.586 17.414 Z M 2 16 L 3 16 C 3 15.735 3.105 15.48 3.293 15.293 L 2.586 14.586 L 1.879 13.879 C 1.316 14.441 1 15.204 1 16 L 2 16 Z M 2.586 14.586 L 3.293 15.293 C 3.48 15.105 3.735 15 4 15 L 4 14 L 4 13 C 3.204 13 2.441 13.316 1.879 13.879 L 2.586 14.586 Z M 4 14 L 4 15 C 4.265 15 4.52 15.105 4.707 15.293 L 5.414 14.586 L 6.121 13.879 C 5.559 13.316 4.796 13 4 13 L 4 14 Z M 5.414 14.586 L 4.707 15.293 C 4.895 15.48 5 15.735 5 16 L 6 16 L 7 16 C 7 15.204 6.684 14.441 6.121 13.879 L 5.414 14.586 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "IconOutlineSparkles": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 3 0 C 3 -0.552 2.552 -1 2 -1 C 1.448 -1 1 -0.552 1 0 L 2 0 L 3 0 Z M 1 4 C 1 4.552 1.448 5 2 5 C 2.552 5 3 4.552 3 4 L 2 4 L 1 4 Z M 0 1 C -0.552 1 -1 1.448 -1 2 C -1 2.552 -0.552 3 0 3 L 0 2 L 0 1 Z M 4 3 C 4.552 3 5 2.552 5 2 C 5 1.448 4.552 1 4 1 L 4 2 L 4 3 Z M 4 14 C 4 13.448 3.552 13 3 13 C 2.448 13 2 13.448 2 14 L 3 14 L 4 14 Z M 2 18 C 2 18.552 2.448 19 3 19 C 3.552 19 4 18.552 4 18 L 3 18 L 2 18 Z M 1 15 C 0.448 15 0 15.448 0 16 C 0 16.552 0.448 17 1 17 L 1 16 L 1 15 Z M 5 17 C 5.552 17 6 16.552 6 16 C 6 15.448 5.552 15 5 15 L 5 16 L 5 17 Z M 10 0 L 10.949 -0.316 C 10.813 -0.725 10.43 -1 10 -1 C 9.57 -1 9.187 -0.725 9.051 -0.316 L 10 0 Z M 12.286 6.857 L 11.337 7.173 C 11.433 7.46 11.652 7.687 11.935 7.793 L 12.286 6.857 Z M 18 9 L 18.351 9.936 C 18.741 9.79 19 9.417 19 9 C 19 8.583 18.741 8.21 18.351 8.064 L 18 9 Z M 12.286 11.143 L 11.935 10.207 C 11.652 10.313 11.433 10.54 11.337 10.827 L 12.286 11.143 Z M 10 18 L 9.051 18.316 C 9.187 18.725 9.57 19 10 19 C 10.43 19 10.813 18.725 10.949 18.316 L 10 18 Z M 7.714 11.143 L 8.663 10.827 C 8.567 10.54 8.348 10.313 8.065 10.207 L 7.714 11.143 Z M 2 9 L 1.649 8.064 C 1.259 8.21 1 8.583 1 9 C 1 9.417 1.259 9.79 1.649 9.936 L 2 9 Z M 7.714 6.857 L 8.065 7.793 C 8.348 7.687 8.567 7.46 8.663 7.173 L 7.714 6.857 Z M 2 0 L 1 0 L 1 4 L 2 4 L 3 4 L 3 0 L 2 0 Z M 2 4 L 3 4 L 3 0 L 2 0 L 1 0 L 1 4 L 2 4 Z M 0 2 L 0 3 L 4 3 L 4 2 L 4 1 L 0 1 L 0 2 Z M 4 2 L 4 1 L 0 1 L 0 2 L 0 3 L 4 3 L 4 2 Z M 3 14 L 2 14 L 2 18 L 3 18 L 4 18 L 4 14 L 3 14 Z M 3 18 L 4 18 L 4 14 L 3 14 L 2 14 L 2 18 L 3 18 Z M 1 16 L 1 17 L 5 17 L 5 16 L 5 15 L 1 15 L 1 16 Z M 5 16 L 5 15 L 1 15 L 1 16 L 1 17 L 5 17 L 5 16 Z M 10 0 L 9.051 0.316 L 11.337 7.173 L 12.286 6.857 L 13.235 6.541 L 10.949 -0.316 L 10 0 Z M 12.286 6.857 L 11.935 7.793 L 17.649 9.936 L 18 9 L 18.351 8.064 L 12.637 5.921 L 12.286 6.857 Z M 18 9 L 17.649 8.064 L 11.935 10.207 L 12.286 11.143 L 12.637 12.079 L 18.351 9.936 L 18 9 Z M 12.286 11.143 L 11.337 10.827 L 9.051 17.684 L 10 18 L 10.949 18.316 L 13.235 11.459 L 12.286 11.143 Z M 10 18 L 10.949 17.684 L 8.663 10.827 L 7.714 11.143 L 6.765 11.459 L 9.051 18.316 L 10 18 Z M 7.714 11.143 L 8.065 10.207 L 2.351 8.064 L 2 9 L 1.649 9.936 L 7.363 12.079 L 7.714 11.143 Z M 2 9 L 2.351 9.936 L 8.065 7.793 L 7.714 6.857 L 7.363 5.921 L 1.649 8.064 L 2 9 Z M 7.714 6.857 L 8.663 7.173 L 10.949 0.316 L 10 0 L 9.051 -0.316 L 6.765 6.541 L 7.714 6.857 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "IconOutlineStar": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 8.386 0.691 L 7.435 0.381 L 7.435 0.382 L 8.386 0.691 Z M 10.288 0.691 L 9.337 1 L 9.337 1 L 10.288 0.691 Z M 11.807 5.365 L 10.856 5.674 L 10.856 5.675 L 11.807 5.365 Z M 12.757 6.055 L 12.756 7.055 L 12.757 7.055 L 12.757 6.055 Z M 18.26 7.865 L 18.848 8.674 L 18.849 8.673 L 18.26 7.865 Z M 14.284 10.753 L 13.696 9.944 L 13.696 9.944 L 14.284 10.753 Z M 13.921 11.871 L 14.872 11.562 L 14.872 11.562 L 13.921 11.871 Z M 15.439 16.545 L 14.488 16.854 L 14.488 16.854 L 15.439 16.545 Z M 13.901 17.663 L 14.49 16.854 L 14.489 16.854 L 13.901 17.663 Z M 9.925 14.775 L 9.337 15.584 L 9.337 15.584 L 9.925 14.775 Z M 8.749 14.775 L 9.337 15.584 L 9.337 15.584 L 8.749 14.775 Z M 4.773 17.663 L 4.185 16.854 L 4.184 16.854 L 4.773 17.663 Z M 3.235 16.545 L 4.186 16.854 L 4.186 16.854 L 3.235 16.545 Z M 4.753 11.871 L 3.802 11.562 L 3.802 11.562 L 4.753 11.871 Z M 4.39 10.753 L 4.978 9.944 L 4.978 9.944 L 4.39 10.753 Z M 0.414 7.865 L -0.174 8.674 L -0.174 8.674 L 0.414 7.865 Z M 5.916 6.055 L 5.916 5.055 L 5.916 5.055 L 5.916 6.055 Z M 6.867 5.365 L 7.818 5.675 L 7.818 5.674 L 6.867 5.365 Z M 8.386 0.691 L 9.337 1 L 9.337 1 L 10.288 0.691 L 11.239 0.382 C 10.64 -1.462 8.034 -1.459 7.435 0.381 L 8.386 0.691 Z M 10.288 0.691 L 9.337 1 L 10.856 5.674 L 11.807 5.365 L 12.758 5.056 L 11.239 0.382 L 10.288 0.691 Z M 11.807 5.365 L 10.856 5.675 C 10.987 6.076 11.241 6.425 11.582 6.673 L 12.17 5.864 L 12.758 5.055 L 12.758 5.055 L 11.807 5.365 Z M 12.17 5.864 L 11.582 6.673 C 11.924 6.921 12.335 7.054 12.756 7.055 L 12.757 6.055 L 12.758 5.055 L 12.758 5.055 L 12.17 5.864 Z M 12.757 6.055 L 12.757 7.055 L 17.672 7.055 L 17.672 6.055 L 17.672 5.055 L 12.757 5.055 L 12.757 6.055 Z M 17.672 6.055 L 17.672 7.055 C 17.679 7.055 17.683 7.055 17.684 7.056 C 17.686 7.056 17.685 7.056 17.683 7.055 C 17.679 7.054 17.675 7.051 17.671 7.048 C 17.667 7.046 17.667 7.044 17.668 7.045 C 17.669 7.047 17.67 7.05 17.672 7.055 C 17.673 7.059 17.674 7.063 17.674 7.065 C 17.674 7.067 17.674 7.065 17.675 7.061 C 17.676 7.057 17.678 7.052 17.681 7.049 C 17.682 7.048 17.682 7.047 17.681 7.048 C 17.68 7.049 17.677 7.052 17.671 7.056 L 18.26 7.865 L 18.849 8.673 C 20.412 7.535 19.613 5.055 17.672 5.055 L 17.672 6.055 Z M 18.26 7.865 L 17.672 7.056 L 13.696 9.944 L 14.284 10.753 L 14.872 11.562 L 18.848 8.674 L 18.26 7.865 Z M 14.284 10.753 L 13.696 9.944 C 13.354 10.192 13.1 10.542 12.97 10.944 L 13.921 11.253 L 14.872 11.562 L 14.872 11.562 L 14.284 10.753 Z M 13.921 11.253 L 12.97 10.944 C 12.839 11.346 12.839 11.778 12.97 12.18 L 13.921 11.871 L 14.872 11.562 L 14.872 11.562 L 13.921 11.253 Z M 13.921 11.871 L 12.97 12.18 L 14.488 16.854 L 15.439 16.545 L 16.39 16.236 L 14.872 11.562 L 13.921 11.871 Z M 15.439 16.545 L 14.488 16.854 C 14.49 16.861 14.491 16.865 14.491 16.866 C 14.491 16.868 14.491 16.867 14.491 16.865 C 14.491 16.861 14.492 16.856 14.494 16.851 C 14.495 16.847 14.496 16.846 14.496 16.847 C 14.495 16.849 14.492 16.851 14.488 16.854 C 14.485 16.857 14.481 16.858 14.48 16.859 C 14.478 16.86 14.48 16.859 14.484 16.859 C 14.489 16.858 14.494 16.859 14.499 16.861 C 14.501 16.861 14.501 16.861 14.5 16.861 C 14.499 16.86 14.495 16.858 14.49 16.854 L 13.901 17.663 L 13.312 18.471 C 14.88 19.612 16.99 18.078 16.39 16.235 L 15.439 16.545 Z M 13.901 17.663 L 14.489 16.854 L 10.513 13.966 L 9.925 14.775 L 9.337 15.584 L 13.313 18.472 L 13.901 17.663 Z M 9.925 14.775 L 10.513 13.966 C 10.171 13.717 9.76 13.584 9.337 13.584 L 9.337 14.584 L 9.337 15.584 L 9.337 15.584 L 9.925 14.775 Z M 9.337 14.584 L 9.337 13.584 C 8.914 13.584 8.503 13.717 8.161 13.966 L 8.749 14.775 L 9.337 15.584 L 9.337 15.584 L 9.337 14.584 Z M 8.749 14.775 L 8.161 13.966 L 4.185 16.854 L 4.773 17.663 L 5.361 18.472 L 9.337 15.584 L 8.749 14.775 Z M 4.773 17.663 L 4.184 16.854 C 4.179 16.858 4.175 16.86 4.174 16.861 C 4.173 16.861 4.174 16.861 4.176 16.86 C 4.18 16.859 4.185 16.858 4.19 16.858 C 4.195 16.859 4.196 16.859 4.195 16.859 C 4.193 16.858 4.19 16.857 4.186 16.854 C 4.182 16.851 4.18 16.849 4.178 16.847 C 4.178 16.846 4.179 16.847 4.18 16.851 C 4.182 16.855 4.183 16.861 4.183 16.865 C 4.183 16.867 4.183 16.868 4.183 16.866 C 4.183 16.865 4.184 16.861 4.186 16.854 L 3.235 16.545 L 2.284 16.235 C 1.684 18.076 3.793 19.613 5.362 18.471 L 4.773 17.663 Z M 3.235 16.545 L 4.186 16.854 L 5.704 12.18 L 4.753 11.871 L 3.802 11.562 L 2.284 16.236 L 3.235 16.545 Z M 4.753 11.871 L 5.704 12.18 C 5.835 11.778 5.835 11.346 5.704 10.944 L 4.753 11.253 L 3.802 11.562 L 3.802 11.562 L 4.753 11.871 Z M 4.753 11.253 L 5.704 10.944 C 5.574 10.542 5.32 10.192 4.978 9.944 L 4.39 10.753 L 3.802 11.562 L 3.802 11.562 L 4.753 11.253 Z M 4.39 10.753 L 4.978 9.944 L 1.002 7.056 L 0.414 7.865 L -0.174 8.674 L 3.802 11.562 L 4.39 10.753 Z M 0.414 7.865 L 1.002 7.056 C 0.996 7.052 0.993 7.049 0.992 7.048 C 0.992 7.047 0.992 7.047 0.993 7.049 C 0.995 7.052 0.998 7.057 0.999 7.062 C 1 7.066 1 7.067 1 7.066 C 1 7.064 1 7.06 1.002 7.055 C 1.003 7.051 1.005 7.047 1.006 7.046 C 1.007 7.044 1.007 7.046 1.003 7.048 C 1 7.051 0.995 7.054 0.991 7.055 C 0.989 7.056 0.989 7.056 0.99 7.056 C 0.991 7.055 0.995 7.055 1.002 7.055 L 1.002 6.055 L 1.002 5.055 C -0.934 5.055 -1.742 7.534 -0.174 8.674 L 0.414 7.865 Z M 1.002 6.055 L 1.002 7.055 L 5.916 7.055 L 5.916 6.055 L 5.916 5.055 L 1.002 5.055 L 1.002 6.055 Z M 5.916 6.055 L 5.916 7.055 C 6.338 7.055 6.749 6.921 7.091 6.674 L 6.504 5.864 L 5.916 5.055 L 5.916 5.055 L 5.916 6.055 Z M 6.504 5.864 L 7.091 6.674 C 7.432 6.426 7.687 6.076 7.818 5.675 L 6.867 5.365 L 5.916 5.055 L 5.916 5.055 L 6.504 5.864 Z M 6.867 5.365 L 7.818 5.674 L 9.337 1 L 8.386 0.691 L 7.435 0.382 L 5.916 5.056 L 6.867 5.365 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.663 2.236)\"/>"
  },
  "IconOutlineTruck": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 4 2 L 3.5 2 L 4 2 Z M 0 2 L -0.5 2 L 0 2 Z M 2 0 L 2 0.5 L 2 0 Z M 12 0 L 12 0.5 L 12 0 Z M 4 2 L 3.5 2 C 3.5 2.398 3.342 2.779 3.061 3.061 L 3.414 3.414 L 3.768 3.768 C 4.237 3.299 4.5 2.663 4.5 2 L 4 2 Z M 3.414 3.414 L 3.061 3.061 C 2.779 3.342 2.398 3.5 2 3.5 L 2 4 L 2 4.5 C 2.663 4.5 3.299 4.237 3.768 3.768 L 3.414 3.414 Z M 2 4 L 2 3.5 C 1.602 3.5 1.221 3.342 0.939 3.061 L 0.586 3.414 L 0.232 3.768 C 0.701 4.237 1.337 4.5 2 4.5 L 2 4 Z M 0.586 3.414 L 0.939 3.061 C 0.658 2.779 0.5 2.398 0.5 2 L 0 2 L -0.5 2 C -0.5 2.663 -0.237 3.299 0.232 3.768 L 0.586 3.414 Z M 0 2 L 0.5 2 C 0.5 1.602 0.658 1.221 0.939 0.939 L 0.586 0.586 L 0.232 0.232 C -0.237 0.701 -0.5 1.337 -0.5 2 L 0 2 Z M 0.586 0.586 L 0.939 0.939 C 1.221 0.658 1.602 0.5 2 0.5 L 2 0 L 2 -0.5 C 1.337 -0.5 0.701 -0.237 0.232 0.232 L 0.586 0.586 Z M 2 0 L 2 0.5 C 2.398 0.5 2.779 0.658 3.061 0.939 L 3.414 0.586 L 3.768 0.232 C 3.299 -0.237 2.663 -0.5 2 -0.5 L 2 0 Z M 3.414 0.586 L 3.061 0.939 C 3.342 1.221 3.5 1.602 3.5 2 L 4 2 L 4.5 2 C 4.5 1.337 4.237 0.701 3.768 0.232 L 3.414 0.586 Z M 14 2 L 13.5 2 C 13.5 2.398 13.342 2.779 13.061 3.061 L 13.414 3.414 L 13.768 3.768 C 14.237 3.299 14.5 2.663 14.5 2 L 14 2 Z M 13.414 3.414 L 13.061 3.061 C 12.779 3.342 12.398 3.5 12 3.5 L 12 4 L 12 4.5 C 12.663 4.5 13.299 4.237 13.768 3.768 L 13.414 3.414 Z M 12 4 L 12 3.5 C 11.602 3.5 11.221 3.342 10.939 3.061 L 10.586 3.414 L 10.232 3.768 C 10.701 4.237 11.337 4.5 12 4.5 L 12 4 Z M 10.586 3.414 L 10.939 3.061 C 10.658 2.779 10.5 2.398 10.5 2 L 10 2 L 9.5 2 C 9.5 2.663 9.763 3.299 10.232 3.768 L 10.586 3.414 Z M 10 2 L 10.5 2 C 10.5 1.602 10.658 1.221 10.939 0.939 L 10.586 0.586 L 10.232 0.232 C 9.763 0.701 9.5 1.337 9.5 2 L 10 2 Z M 10.586 0.586 L 10.939 0.939 C 11.221 0.658 11.602 0.5 12 0.5 L 12 0 L 12 -0.5 C 11.337 -0.5 10.701 -0.237 10.232 0.232 L 10.586 0.586 Z M 12 0 L 12 0.5 C 12.398 0.5 12.779 0.658 13.061 0.939 L 13.414 0.586 L 13.768 0.232 C 13.299 -0.237 12.663 -0.5 12 -0.5 L 12 0 Z M 13.414 0.586 L 13.061 0.939 C 13.342 1.221 13.5 1.602 13.5 2 L 14 2 L 14.5 2 C 14.5 1.337 14.237 0.701 13.768 0.232 L 13.414 0.586 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 15)\"/><path d=\"M 0 1 L -1 1 L 0 1 Z M 0 11 L -1 11 L 0 11 Z M 6 12 L 5 12 L 6 12 Z M 11 2 L 11 3 L 11 2 Z M 13.586 2 L 13.586 1 L 13.586 1 L 13.586 2 Z M 14.293 2.293 L 13.586 3 L 13.586 3 L 14.293 2.293 Z M 17.707 5.707 L 17 6.414 L 17 6.414 L 17.707 5.707 Z M 18 6.414 L 19 6.414 L 19 6.414 L 18 6.414 Z M 4 10 L 4 11 L 4 10 Z M 14 10 L 14 11 L 14 10 Z M 10 11 L 11 11 L 11 1 L 10 1 L 9 1 L 9 11 L 10 11 Z M 10 1 L 11 1 C 11 0.47 10.789 -0.039 10.414 -0.414 L 9.707 0.293 L 9 1 L 9 1 L 10 1 Z M 9.707 0.293 L 10.414 -0.414 C 10.039 -0.789 9.53 -1 9 -1 L 9 0 L 9 1 L 9 1 L 9.707 0.293 Z M 9 0 L 9 -1 L 1 -1 L 1 0 L 1 1 L 9 1 L 9 0 Z M 1 0 L 1 -1 C 0.47 -1 -0.039 -0.789 -0.414 -0.414 L 0.293 0.293 L 1 1 L 1 1 L 1 0 Z M 0.293 0.293 L -0.414 -0.414 C -0.789 -0.039 -1 0.47 -1 1 L 0 1 L 1 1 L 1 1 L 0.293 0.293 Z M 0 1 L -1 1 L -1 11 L 0 11 L 1 11 L 1 1 L 0 1 Z M 0 11 L -1 11 C -1 11.53 -0.789 12.039 -0.414 12.414 L 0.293 11.707 L 1 11 L 1 11 L 0 11 Z M 0.293 11.707 L -0.414 12.414 C -0.039 12.789 0.47 13 1 13 L 1 12 L 1 11 L 1 11 L 0.293 11.707 Z M 1 12 L 1 13 L 2 13 L 2 12 L 2 11 L 1 11 L 1 12 Z M 10 11 L 9 11 L 9 11 L 9.707 11.707 L 10.414 12.414 C 10.789 12.039 11 11.53 11 11 L 10 11 Z M 9.707 11.707 L 9 11 L 9 11 L 9 12 L 9 13 C 9.53 13 10.039 12.789 10.414 12.414 L 9.707 11.707 Z M 9 12 L 9 11 L 6 11 L 6 12 L 6 13 L 9 13 L 9 12 Z M 10 11 L 11 11 L 11 3 L 10 3 L 9 3 L 9 11 L 10 11 Z M 10 3 L 11 3 L 11 3 L 10.293 2.293 L 9.586 1.586 C 9.211 1.961 9 2.47 9 3 L 10 3 Z M 10.293 2.293 L 11 3 L 11 3 L 11 2 L 11 1 C 10.47 1 9.961 1.211 9.586 1.586 L 10.293 2.293 Z M 11 2 L 11 3 L 13.586 3 L 13.586 2 L 13.586 1 L 11 1 L 11 2 Z M 13.586 2 L 13.586 3 L 13.586 3 L 14.293 2.293 L 15 1.586 C 14.625 1.211 14.117 1 13.586 1 L 13.586 2 Z M 14.293 2.293 L 13.586 3 L 17 6.414 L 17.707 5.707 L 18.414 5 L 15 1.586 L 14.293 2.293 Z M 17.707 5.707 L 17 6.414 L 17 6.414 L 18 6.414 L 19 6.414 C 19 5.883 18.789 5.375 18.414 5 L 17.707 5.707 Z M 18 6.414 L 17 6.414 L 17 11 L 18 11 L 19 11 L 19 6.414 L 18 6.414 Z M 18 11 L 17 11 L 17 11 L 17.707 11.707 L 18.414 12.414 C 18.789 12.039 19 11.53 19 11 L 18 11 Z M 17.707 11.707 L 17 11 L 17 11 L 17 12 L 17 13 C 17.53 13 18.039 12.789 18.414 12.414 L 17.707 11.707 Z M 17 12 L 17 11 L 16 11 L 16 12 L 16 13 L 17 13 L 17 12 Z M 10 11 L 9 11 C 9 11.53 9.211 12.039 9.586 12.414 L 10.293 11.707 L 11 11 L 11 11 L 10 11 Z M 10.293 11.707 L 9.586 12.414 C 9.961 12.789 10.47 13 11 13 L 11 12 L 11 11 L 11 11 L 10.293 11.707 Z M 11 12 L 11 13 L 12 13 L 12 12 L 12 11 L 11 11 L 11 12 Z M 2 12 L 1 12 C 1 12.796 1.316 13.559 1.879 14.121 L 2.586 13.414 L 3.293 12.707 C 3.105 12.52 3 12.265 3 12 L 2 12 Z M 2.586 13.414 L 1.879 14.121 C 2.441 14.684 3.204 15 4 15 L 4 14 L 4 13 C 3.735 13 3.48 12.895 3.293 12.707 L 2.586 13.414 Z M 4 14 L 4 15 C 4.796 15 5.559 14.684 6.121 14.121 L 5.414 13.414 L 4.707 12.707 C 4.52 12.895 4.265 13 4 13 L 4 14 Z M 5.414 13.414 L 6.121 14.121 C 6.684 13.559 7 12.796 7 12 L 6 12 L 5 12 C 5 12.265 4.895 12.52 4.707 12.707 L 5.414 13.414 Z M 2 12 L 3 12 C 3 11.735 3.105 11.48 3.293 11.293 L 2.586 10.586 L 1.879 9.879 C 1.316 10.441 1 11.204 1 12 L 2 12 Z M 2.586 10.586 L 3.293 11.293 C 3.48 11.105 3.735 11 4 11 L 4 10 L 4 9 C 3.204 9 2.441 9.316 1.879 9.879 L 2.586 10.586 Z M 4 10 L 4 11 C 4.265 11 4.52 11.105 4.707 11.293 L 5.414 10.586 L 6.121 9.879 C 5.559 9.316 4.796 9 4 9 L 4 10 Z M 5.414 10.586 L 4.707 11.293 C 4.895 11.48 5 11.735 5 12 L 6 12 L 7 12 C 7 11.204 6.684 10.441 6.121 9.879 L 5.414 10.586 Z M 12 12 L 11 12 C 11 12.796 11.316 13.559 11.879 14.121 L 12.586 13.414 L 13.293 12.707 C 13.105 12.52 13 12.265 13 12 L 12 12 Z M 12.586 13.414 L 11.879 14.121 C 12.441 14.684 13.204 15 14 15 L 14 14 L 14 13 C 13.735 13 13.48 12.895 13.293 12.707 L 12.586 13.414 Z M 14 14 L 14 15 C 14.796 15 15.559 14.684 16.121 14.121 L 15.414 13.414 L 14.707 12.707 C 14.52 12.895 14.265 13 14 13 L 14 14 Z M 15.414 13.414 L 16.121 14.121 C 16.684 13.559 17 12.796 17 12 L 16 12 L 15 12 C 15 12.265 14.895 12.52 14.707 12.707 L 15.414 13.414 Z M 12 12 L 13 12 C 13 11.735 13.105 11.48 13.293 11.293 L 12.586 10.586 L 11.879 9.879 C 11.316 10.441 11 11.204 11 12 L 12 12 Z M 12.586 10.586 L 13.293 11.293 C 13.48 11.105 13.735 11 14 11 L 14 10 L 14 9 C 13.204 9 12.441 9.316 11.879 9.879 L 12.586 10.586 Z M 14 10 L 14 11 C 14.265 11 14.52 11.105 14.707 11.293 L 15.414 10.586 L 16.121 9.879 C 15.559 9.316 14.796 9 14 9 L 14 10 Z M 15.414 10.586 L 14.707 11.293 C 14.895 11.48 15 11.735 15 12 L 16 12 L 17 12 C 17 11.204 16.684 10.441 16.121 9.879 L 15.414 10.586 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
  },
  "IconOutlineUser": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 11 4 L 12 4 L 11 4 Z M 7 8 L 7 9 L 7 8 Z M 3 4 L 2 4 L 3 4 Z M 7 0 L 7 -1 L 7 0 Z M 7 11 L 7 10 L 7 11 Z M 0 18 L -1 18 C -1 18.265 -0.895 18.52 -0.707 18.707 C -0.52 18.895 -0.265 19 0 19 L 0 18 Z M 14 18 L 14 19 C 14.552 19 15 18.552 15 18 L 14 18 Z M 11 4 L 10 4 C 10 4.796 9.684 5.559 9.121 6.121 L 9.828 6.828 L 10.536 7.536 C 11.473 6.598 12 5.326 12 4 L 11 4 Z M 9.828 6.828 L 9.121 6.121 C 8.559 6.684 7.796 7 7 7 L 7 8 L 7 9 C 8.326 9 9.598 8.473 10.536 7.536 L 9.828 6.828 Z M 7 8 L 7 7 C 6.204 7 5.441 6.684 4.879 6.121 L 4.172 6.828 L 3.464 7.536 C 4.402 8.473 5.674 9 7 9 L 7 8 Z M 4.172 6.828 L 4.879 6.121 C 4.316 5.559 4 4.796 4 4 L 3 4 L 2 4 C 2 5.326 2.527 6.598 3.464 7.536 L 4.172 6.828 Z M 3 4 L 4 4 C 4 3.204 4.316 2.441 4.879 1.879 L 4.172 1.172 L 3.464 0.464 C 2.527 1.402 2 2.674 2 4 L 3 4 Z M 4.172 1.172 L 4.879 1.879 C 5.441 1.316 6.204 1 7 1 L 7 0 L 7 -1 C 5.674 -1 4.402 -0.473 3.464 0.464 L 4.172 1.172 Z M 7 0 L 7 1 C 7.796 1 8.559 1.316 9.121 1.879 L 9.828 1.172 L 10.536 0.464 C 9.598 -0.473 8.326 -1 7 -1 L 7 0 Z M 9.828 1.172 L 9.121 1.879 C 9.684 2.441 10 3.204 10 4 L 11 4 L 12 4 C 12 2.674 11.473 1.402 10.536 0.464 L 9.828 1.172 Z M 7 11 L 7 10 C 4.878 10 2.843 10.843 1.343 12.343 L 2.05 13.05 L 2.757 13.757 C 3.883 12.632 5.409 12 7 12 L 7 11 Z M 2.05 13.05 L 1.343 12.343 C -0.157 13.843 -1 15.878 -1 18 L 0 18 L 1 18 C 1 16.409 1.632 14.883 2.757 13.757 L 2.05 13.05 Z M 0 18 L 0 19 L 14 19 L 14 18 L 14 17 L 0 17 L 0 18 Z M 14 18 L 15 18 C 15 15.878 14.157 13.843 12.657 12.343 L 11.95 13.05 L 11.243 13.757 C 12.368 14.883 13 16.409 13 18 L 14 18 Z M 11.95 13.05 L 12.657 12.343 C 11.157 10.843 9.122 10 7 10 L 7 11 L 7 12 C 8.591 12 10.117 12.632 11.243 13.757 L 11.95 13.05 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 3)\"/>"
  },
  "IconSolidHeart": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 1.405 1.465 C 2.306 0.566 3.526 0.06 4.799 0.06 C 6.072 0.06 7.292 0.566 8.193 1.465 L 9.599 2.871 L 11.005 1.465 C 11.448 1.007 11.978 0.641 12.563 0.39 C 13.149 0.138 13.779 0.006 14.416 0 C 15.054 -0.005 15.686 0.116 16.276 0.357 C 16.865 0.599 17.401 0.955 17.852 1.406 C 18.303 1.857 18.659 2.393 18.901 2.982 C 19.142 3.572 19.263 4.204 19.258 4.842 C 19.252 5.479 19.12 6.109 18.868 6.695 C 18.617 7.28 18.251 7.81 17.793 8.253 L 9.599 16.447 L 1.405 8.253 C 0.506 7.352 0 6.132 0 4.859 C 0 3.586 0.506 2.366 1.405 1.465 L 1.405 1.465 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 2.401 4.741)\"/>"
  },
  "IconSolidPlay": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 9.6 19.2 C 12.146 19.2 14.588 18.189 16.388 16.388 C 18.189 14.588 19.2 12.146 19.2 9.6 C 19.2 7.054 18.189 4.612 16.388 2.812 C 14.588 1.011 12.146 0 9.6 0 C 7.054 0 4.612 1.011 2.812 2.812 C 1.011 4.612 0 7.054 0 9.6 C 0 12.146 1.011 14.588 2.812 16.388 C 4.612 18.189 7.054 19.2 9.6 19.2 L 9.6 19.2 Z M 9.066 6.202 C 8.885 6.081 8.675 6.012 8.458 6.001 C 8.241 5.991 8.025 6.039 7.834 6.142 C 7.642 6.244 7.482 6.397 7.371 6.583 C 7.259 6.77 7.2 6.983 7.2 7.2 L 7.2 12 C 7.2 12.217 7.259 12.43 7.371 12.617 C 7.482 12.803 7.642 12.956 7.834 13.058 C 8.025 13.161 8.241 13.209 8.458 13.199 C 8.675 13.188 8.885 13.119 9.066 12.998 L 12.666 10.598 C 12.83 10.489 12.965 10.34 13.058 10.166 C 13.152 9.992 13.2 9.798 13.2 9.6 C 13.2 9.402 13.152 9.208 13.058 9.034 C 12.965 8.86 12.83 8.711 12.666 8.602 L 9.066 6.202 L 9.066 6.202 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 2.400 2.400)\"/>"
  },
  "IconSolidStar": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 7.779 0.829 C 8.139 -0.276 9.703 -0.276 10.061 0.829 L 11.345 4.779 C 11.424 5.02 11.576 5.23 11.781 5.378 C 11.986 5.527 12.232 5.607 12.485 5.607 L 16.64 5.607 C 17.803 5.607 18.285 7.095 17.345 7.779 L 13.985 10.22 C 13.78 10.369 13.628 10.579 13.549 10.82 C 13.471 11.061 13.47 11.321 13.549 11.562 L 14.833 15.512 C 15.193 16.617 13.927 17.538 12.985 16.854 L 9.625 14.413 C 9.42 14.264 9.173 14.184 8.92 14.184 C 8.666 14.184 8.42 14.264 8.215 14.413 L 4.855 16.854 C 3.914 17.538 2.649 16.617 3.008 15.512 L 4.292 11.562 C 4.37 11.321 4.37 11.061 4.291 10.82 C 4.213 10.579 4.06 10.369 3.855 10.22 L 0.496 7.781 C -0.443 7.097 0.04 5.609 1.202 5.609 L 5.355 5.609 C 5.608 5.609 5.855 5.529 6.06 5.38 C 6.265 5.231 6.418 5.021 6.496 4.78 L 7.78 0.83 L 7.779 0.829 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.080 2.684)\"/>"
  },
  "MediumSocialsFacebook": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 3.299 18 L 3.273 9.818 L 0 9.818 L 0 6.545 L 3.273 6.545 L 3.273 4.5 C 3.273 1.463 5.153 0 7.862 0 C 9.16 0 10.275 0.097 10.6 0.14 L 10.6 3.313 L 8.721 3.314 C 7.248 3.314 6.963 4.014 6.963 5.041 L 6.963 6.545 L 11.25 6.545 L 9.614 9.818 L 6.963 9.818 L 6.963 18 L 3.299 18 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 6 3)\"/>"
  },
  "MediumSocialsInstagram": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 9 1.622 C 11.403 1.622 11.688 1.631 12.637 1.674 C 13.514 1.714 13.991 1.861 14.308 1.984 C 14.728 2.147 15.028 2.342 15.343 2.657 C 15.658 2.972 15.853 3.272 16.016 3.692 C 16.139 4.009 16.286 4.486 16.326 5.363 C 16.369 6.312 16.378 6.597 16.378 9 C 16.378 11.403 16.369 11.688 16.326 12.637 C 16.286 13.514 16.139 13.991 16.016 14.308 C 15.853 14.728 15.658 15.028 15.343 15.343 C 15.028 15.658 14.728 15.853 14.308 16.016 C 13.991 16.139 13.514 16.286 12.637 16.326 C 11.688 16.369 11.403 16.378 9 16.378 C 6.597 16.378 6.312 16.369 5.363 16.326 C 4.486 16.286 4.009 16.139 3.692 16.016 C 3.272 15.853 2.972 15.658 2.657 15.343 C 2.342 15.028 2.147 14.728 1.984 14.308 C 1.861 13.991 1.714 13.514 1.674 12.637 C 1.631 11.688 1.622 11.403 1.622 9 C 1.622 6.597 1.631 6.312 1.674 5.363 C 1.714 4.486 1.861 4.009 1.984 3.692 C 2.147 3.272 2.342 2.972 2.657 2.657 C 2.972 2.342 3.272 2.147 3.692 1.984 C 4.009 1.861 4.486 1.714 5.363 1.674 C 6.312 1.631 6.597 1.622 9 1.622 Z M 9 0 C 6.556 0 6.249 0.01 5.289 0.054 C 4.331 0.098 3.677 0.25 3.105 0.473 C 2.513 0.703 2.011 1.01 1.511 1.511 C 1.01 2.011 0.702 2.513 0.472 3.105 C 0.25 3.677 0.098 4.331 0.054 5.289 C 0.01 6.249 0 6.556 0 9 C 0 11.444 0.01 11.751 0.054 12.711 C 0.098 13.669 0.25 14.323 0.472 14.895 C 0.702 15.487 1.01 15.989 1.511 16.489 C 2.011 16.99 2.513 17.298 3.105 17.528 C 3.677 17.75 4.331 17.902 5.289 17.946 C 6.249 17.99 6.556 18 9 18 C 11.444 18 11.751 17.99 12.711 17.946 C 13.669 17.902 14.323 17.75 14.895 17.528 C 15.487 17.298 15.989 16.99 16.489 16.489 C 16.99 15.989 17.297 15.487 17.527 14.895 C 17.75 14.323 17.902 13.669 17.946 12.711 C 17.99 11.751 18 11.444 18 9 C 18 6.556 17.99 6.249 17.946 5.289 C 17.902 4.331 17.75 3.677 17.527 3.105 C 17.297 2.513 16.99 2.011 16.489 1.511 C 15.989 1.01 15.487 0.703 14.895 0.473 C 14.323 0.25 13.669 0.098 12.711 0.054 C 11.751 0.01 11.444 0 9 0 Z M 9 4.378 C 6.448 4.378 4.378 6.448 4.378 9 C 4.378 11.552 6.448 13.622 9 13.622 C 11.552 13.622 13.622 11.552 13.622 9 C 13.622 6.448 11.552 4.378 9 4.378 Z M 9 12 C 7.343 12 6 10.657 6 9 C 6 7.343 7.343 6 9 6 C 10.657 6 12 7.343 12 9 C 12 10.657 10.657 12 9 12 Z M 14.884 4.196 C 14.884 4.792 14.401 5.276 13.804 5.276 C 13.208 5.276 12.724 4.792 12.724 4.196 C 12.724 3.599 13.208 3.116 13.804 3.116 C 14.401 3.116 14.884 3.599 14.884 4.196 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 3 3)\"/>"
  },
  "MediumSocialsPintrest": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 3.33 19.006 C 4.398 18.065 5.131 16.725 5.489 15.352 C 5.633 14.81 6.222 12.593 6.222 12.593 C 6.603 13.317 7.728 13.926 8.911 13.926 C 12.455 13.926 15.006 10.711 15.006 6.704 C 15.006 2.867 11.837 0 7.763 0 C 2.689 0 0 3.363 0 7.023 C 0 8.722 0.918 10.842 2.384 11.515 C 2.603 11.623 2.724 11.572 2.776 11.356 C 2.811 11.19 3.013 10.409 3.105 10.039 C 3.134 9.925 3.122 9.816 3.024 9.702 C 2.539 9.121 2.147 8.049 2.147 7.057 C 2.147 4.498 4.109 2.018 7.451 2.018 C 10.337 2.018 12.357 3.956 12.357 6.738 C 12.357 9.879 10.752 12.057 8.663 12.057 C 7.509 12.057 6.643 11.116 6.926 9.959 C 7.26 8.579 7.901 7.092 7.901 6.1 C 7.901 5.21 7.422 4.469 6.412 4.469 C 5.229 4.469 4.288 5.672 4.288 7.291 C 4.288 8.317 4.634 9.013 4.634 9.013 C 4.634 9.013 3.469 13.875 3.255 14.782 C 3.018 15.785 3.111 17.193 3.215 18.111 L 3.319 19.011 L 3.33 19.006 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 2) matrix(1 0 0 1 -0.006 -0.006)\"/>"
  },
  "MediumSocialsTiktok": {
    viewBox: "0 0 24 24",
    body: "<path d=\"M 14.008 3.85 C 13.883 3.787 13.762 3.718 13.644 3.643 C 13.302 3.423 12.989 3.163 12.711 2.87 C 12.015 2.094 11.755 1.306 11.659 0.754 L 11.663 0.754 C 11.583 0.296 11.616 0 11.621 0 L 8.45 0 L 8.45 11.954 C 8.45 12.114 8.45 12.273 8.443 12.43 C 8.443 12.449 8.442 12.467 8.44 12.488 C 8.44 12.497 8.44 12.506 8.438 12.515 C 8.438 12.517 8.438 12.519 8.438 12.521 C 8.405 12.95 8.264 13.365 8.028 13.728 C 7.792 14.091 7.468 14.392 7.084 14.605 C 6.684 14.827 6.232 14.943 5.772 14.942 C 4.295 14.942 3.098 13.768 3.098 12.317 C 3.098 10.867 4.295 9.693 5.772 9.693 C 6.052 9.692 6.33 9.735 6.596 9.82 L 6.599 6.672 C 5.792 6.57 4.972 6.633 4.191 6.856 C 3.41 7.079 2.685 7.457 2.061 7.966 C 1.515 8.429 1.056 8.982 0.704 9.599 C 0.57 9.824 0.065 10.728 0.004 12.195 C -0.035 13.028 0.222 13.891 0.344 14.247 L 0.344 14.255 C 0.421 14.465 0.719 15.181 1.205 15.786 C 1.597 16.27 2.059 16.696 2.578 17.049 L 2.578 17.041 L 2.586 17.049 C 4.121 18.066 5.823 17.999 5.823 17.999 C 6.117 17.987 7.104 17.999 8.225 17.481 C 9.468 16.907 10.175 16.052 10.175 16.052 C 10.627 15.541 10.987 14.958 11.238 14.33 C 11.525 13.594 11.621 12.712 11.621 12.36 L 11.621 6.018 C 11.659 6.041 12.172 6.371 12.172 6.371 C 12.172 6.371 12.91 6.832 14.061 7.133 C 14.887 7.346 16 7.391 16 7.391 L 16 4.322 C 15.61 4.364 14.818 4.244 14.008 3.85 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 4 3)\"/>"
  }
};
Object.assign(__ds_scope, { iconData });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/icon-data.js", error: String((e && e.message) || e) }); }

// components/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Icon({
  name,
  size,
  ...rest
}) {
  const d = __ds_scope.iconData[name];
  if (!d) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: d.viewBox,
    fill: "none"
    // body strings are emitter-controlled <path> markup — geometry,
    // numeric fills and transforms only; no .fig-authored text reaches them.
    ,
    dangerouslySetInnerHTML: {
      __html: d.body
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/commerce/ProductCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk ProductCard — the carousel / grid product tile. White card with a
 * cool hairline ring (no drop shadow), tall image on an off-white plinth,
 * promo badges top-left, an optional wishlist heart top-right, then a
 * caption with title, price and the red "dusk Rewards" member price.
 */
function ProductCard({
  image,
  title = 'Sunset Symphony\nScented Candle 90 g',
  price = '$19.99',
  rewardPrice = '$17.99 dusk Rewards',
  badges = [],
  // [{ label, tone }]
  wishlist = true,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      background: 'var(--color-surface)',
      boxShadow: 'var(--ring-card)',
      borderRadius: 'var(--radius-none)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '323 / 411',
      background: 'var(--color-surface-plinth)'
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }), badges.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 16,
      left: 16,
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, badges.map((b, i) => /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    key: i,
    tone: b.tone || 'promo'
  }, b.label))), wishlist && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 16,
      right: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    ariaLabel: "Add to wishlist",
    size: 32
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineHeart",
    size: 16
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      padding: '15px 16px',
      minHeight: 138,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-regular)',
      fontSize: 'var(--fs-h3)',
      lineHeight: 1.2,
      letterSpacing: 'var(--ls-ui)',
      color: 'var(--dusk-ink)',
      whiteSpace: 'pre-line'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-light)',
      fontSize: 'var(--fs-body)',
      color: 'var(--dusk-ink)'
    }
  }, price), rewardPrice && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-light)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-price-reward)'
    }
  }, rewardPrice))));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/commerce/RewardPerk.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk RewardPerk — a circular coral icon medallion with a label beneath,
 * used in the "dusk Rewards" benefits strip (VIP offers, 10% off, $20
 * birthday voucher, extended returns, …).
 */
function RewardPerk({
  icon = 'IconOutlineGift',
  // Icon name
  label = 'VIP Offers & Community Access',
  size = 64,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 12,
      width: 120,
      textAlign: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--color-hero)',
      color: 'var(--dusk-white)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(size * 0.42)
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--fs-label)',
      lineHeight: 1.3,
      color: 'var(--dusk-ink)'
    }
  }, label));
}
Object.assign(__ds_scope, { RewardPerk });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/RewardPerk.jsx", error: String((e && e.message) || e) }); }

// components/marketing/HeroBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk HeroBanner — the full-bleed weekly "web-flip" hero. A photographic
 * background with a colour-wash protection gradient on the text side, an
 * eyebrow lockup, an oversized serif/condensed headline, and a CTA.
 */
function HeroBanner({
  image,
  eyebrow = 'End of Season Sale',
  title = 'Member Exclusive\n30–50% Off Sale Items',
  cta = 'Shop Now',
  footnote = 'T&Cs and exclusions apply.',
  align = 'left',
  // 'left' | 'center'
  wash = 'var(--color-sale)',
  // protection-gradient colour
  height = 550,
  onCta,
  style,
  ...rest
}) {
  const centered = align === 'center';
  const gradient = centered ? `linear-gradient(0deg, ${hexA(wash, 0.55)} 0%, ${hexA(wash, 0)} 60%)` : `linear-gradient(90deg, ${wash} 8%, ${hexA(wash, 0)} 55%)`;
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      position: 'relative',
      width: '100%',
      height,
      overflow: 'hidden',
      background: 'var(--color-surface-plinth)',
      ...style
    }
  }, rest), image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: gradient
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: centered ? 'center' : 'flex-start',
      textAlign: centered ? 'center' : 'left',
      gap: 20,
      padding: centered ? '0 48px' : '0 88px',
      maxWidth: centered ? '100%' : 620,
      boxSizing: 'border-box'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 'var(--fs-h3)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--dusk-white)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 'var(--fs-mega)',
      lineHeight: 1.05,
      letterSpacing: '-0.01em',
      color: 'var(--dusk-white)',
      whiteSpace: 'pre-line'
    }
  }, title), cta && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "inverse",
    onClick: onCta,
    style: {
      marginTop: 8
    }
  }, cta), footnote && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-regular)',
      fontSize: 'var(--fs-small)',
      color: 'var(--dusk-white)',
      opacity: 0.9
    }
  }, footnote)));
}

// translucent variant of a CSS colour token or hex
function hexA(c, a) {
  if (c && c.startsWith('#')) {
    const n = c.slice(1);
    const r = parseInt(n.slice(0, 2), 16),
      g = parseInt(n.slice(2, 4), 16),
      b = parseInt(n.slice(4, 6), 16);
    return `rgba(${r},${g},${b},${a})`;
  }
  // CSS var → wrap with color-mix for translucency
  return `color-mix(in srgb, ${c} ${a * 100}%, transparent)`;
}
Object.assign(__ds_scope, { HeroBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/HeroBanner.jsx", error: String((e && e.message) || e) }); }

// components/marketing/PromoTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk PromoTile — the "Scent of the Moment" / "Deals of the Week" tile:
 * a photo-led panel with an optional badge top-left and a caption (title +
 * CTA) that can sit below the image or overlay it.
 */
function PromoTile({
  image,
  badge,
  // optional { label, tone }
  title = 'Scent of the Moment: Sunset Symphony',
  cta = 'Shop Now',
  overlay = false,
  // caption over the image vs. beneath
  ratio = '16 / 10',
  href = '#',
  style,
  ...rest
}) {
  const titleEl = /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--fs-h3)',
      letterSpacing: 'var(--ls-ui)',
      color: overlay ? 'var(--dusk-white)' : 'var(--dusk-ink)',
      lineHeight: 1.25
    }
  }, title);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      textDecoration: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: ratio,
      background: 'var(--color-surface-plinth)',
      overflow: 'hidden'
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }), badge && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 16,
      left: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: badge.tone || 'neutral'
  }, badge.label)), overlay && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      gap: 14,
      padding: 24,
      background: 'linear-gradient(0deg, rgba(36,36,36,0.55) 0%, rgba(36,36,36,0) 55%)'
    }
  }, titleEl, cta && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "inverse",
    size: "small",
    style: {
      alignSelf: 'flex-start'
    }
  }, cta))), !overlay && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6
    }
  }, titleEl, cta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-small)',
      color: 'var(--text-secondary)',
      textDecoration: 'underline',
      textUnderlineOffset: 3
    }
  }, cta)));
}
Object.assign(__ds_scope, { PromoTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/PromoTile.jsx", error: String((e && e.message) || e) }); }

// components/navigation/DuskLogo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk wordmark.
 *
 * ⚠ SUBSTITUTION: the official wordmark is a custom serif lock-up. The
 * source file only exposed a clean vector for the "d"; the full glyph
 * set could not be extracted. This renders "dusk" in the brand display
 * serif (Shippori Mincho) as a faithful stand-in. Replace with the
 * official SVG when available (see readme · Iconography).
 */
function DuskLogo({
  height = 28,
  tone = 'ink',
  // 'ink' | 'light' | 'hero'
  style,
  ...rest
}) {
  const colors = {
    ink: 'var(--dusk-ink)',
    light: 'var(--dusk-soft-glow)',
    hero: 'var(--color-hero)'
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "img",
    "aria-label": "dusk",
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: height,
      lineHeight: 1,
      letterSpacing: '0.01em',
      color: colors[tone] || colors.ink,
      userSelect: 'none',
      ...style
    }
  }, rest), "dusk");
}
Object.assign(__ds_scope, { DuskLogo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/DuskLogo.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DEFAULT_COLUMNS = [{
  heading: 'About',
  links: ['About us', 'Investors', 'Careers']
}, {
  heading: 'Explore',
  links: ['dusk Rewards', 'Store locator', 'Gift cards', 'My account', 'Promotions', 'Blog']
}, {
  heading: 'Help & Support',
  links: ['Contact us', 'Returns', 'Help Centre', 'Delivery', 'Privacy Policy', 'Terms & Conditions']
}];

/**
 * dusk site Footer — a newsletter sign-up beside three link columns, with
 * a base row carrying the wordmark, socials and country selector.
 */
function Footer({
  columns = DEFAULT_COLUMNS,
  newsletterTitle = 'Brighten up your emails',
  newsletterBlurb = 'Get 10% off your first order and be the first to know about new releases and sales!',
  socials = ['ButtonSocialInstagram', 'ButtonSocialFacebook', 'ButtonSocialPintrest', 'ButtonSocialTiktok'],
  country = 'Australia (AUD $)',
  style,
  ...rest
}) {
  const eyebrow = {
    fontFamily: 'var(--font-fine)',
    fontSize: 'var(--fs-caption)',
    fontWeight: 'var(--weight-medium)',
    letterSpacing: 'var(--ls-eyebrow)',
    textTransform: 'uppercase',
    color: 'var(--text-muted)'
  };
  const link = {
    fontFamily: 'var(--font-sans)',
    fontSize: 'var(--fs-small)',
    fontWeight: 'var(--weight-regular)',
    color: 'var(--text-secondary)',
    textDecoration: 'none',
    cursor: 'pointer'
  };
  return /*#__PURE__*/React.createElement("footer", _extends({
    style: {
      background: 'var(--dusk-white)',
      borderTop: '1px solid var(--dusk-line-on-light)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr 1fr',
      gap: 40,
      maxWidth: 'var(--layout-max)',
      margin: '0 auto',
      padding: '56px var(--layout-gutter)',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      maxWidth: 320
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: eyebrow
  }, newsletterTitle), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-small)',
      lineHeight: 1.5,
      color: 'var(--text-body)'
    }
  }, newsletterBlurb), /*#__PURE__*/React.createElement(__ds_scope.Input, {
    placeholder: "Name"
  }), /*#__PURE__*/React.createElement(__ds_scope.Input, {
    type: "email",
    placeholder: "Email Address"
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "small",
    style: {
      alignSelf: 'flex-start'
    },
    iconRight: /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "IconOutlineArrowNarrowRight",
      size: 14
    })
  }, "Submit")), columns.map((col, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: eyebrow
  }, col.heading), col.links.map((l, j) => /*#__PURE__*/React.createElement("a", {
    key: j,
    href: "#",
    style: link
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--dusk-line-on-light)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24,
      maxWidth: 'var(--layout-max)',
      margin: '0 auto',
      padding: '20px var(--layout-gutter)',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.DuskLogo, {
    height: 22
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      color: 'var(--text-secondary)'
    }
  }, socials.map((s, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    "aria-label": s,
    style: {
      color: 'inherit',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: s,
    size: 18
  }))))), /*#__PURE__*/React.createElement("span", {
    style: {
      ...link,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineGlobe",
    size: 16
  }), country))));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Header.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk site Header — a two-row desktop masthead. A slim utility row
 * (right-aligned links + store picker) sits above the main bar, which
 * carries the left nav, the centred wordmark, and the search / account /
 * wishlist / cart actions.
 */
function Header({
  utilityLinks = ['Blog', 'dusk Rewards', 'Help'],
  navLinks = ['Shop', 'Sale'],
  storeLabel = 'Select your store',
  cartCount = 0,
  style,
  ...rest
}) {
  const linkStyle = {
    fontFamily: 'var(--font-sans)',
    fontSize: 'var(--fs-small)',
    fontWeight: 'var(--weight-regular)',
    color: 'var(--dusk-ink)',
    textDecoration: 'none',
    cursor: 'pointer',
    whiteSpace: 'nowrap'
  };
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      background: 'var(--dusk-white)',
      width: '100%',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      alignItems: 'center',
      gap: 24,
      height: 'var(--header-top)',
      padding: '0 var(--layout-gutter)',
      borderBottom: '1px solid var(--dusk-line-on-light)',
      boxSizing: 'border-box'
    }
  }, utilityLinks.map((l, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: linkStyle
  }, l)), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      ...linkStyle,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineLocationMarker",
    size: 16
  }), storeLabel)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr auto 1fr',
      alignItems: 'center',
      height: 'var(--header-main)',
      padding: '0 var(--layout-gutter)',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 24,
      alignItems: 'center'
    }
  }, navLinks.map((l, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      ...linkStyle,
      fontWeight: 'var(--weight-medium)'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.DuskLogo, {
    height: 30
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      ...linkStyle,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      marginRight: 8
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineSearch",
    size: 20
  }), "Search"), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    variant: "ghost",
    ariaLabel: "Account"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineUser",
    size: 20
  })), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    variant: "ghost",
    ariaLabel: "Wishlist"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineHeart",
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    variant: "ghost",
    ariaLabel: "Cart"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconOutlineShoppingBag",
    size: 20
  })), cartCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -2,
      right: -2,
      minWidth: 16,
      height: 16,
      padding: '0 4px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--color-hero)',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontSize: 10,
      fontWeight: 'var(--weight-medium)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxSizing: 'border-box'
    }
  }, cartCount)))));
}
Object.assign(__ds_scope, { Header });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Header.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Marquee.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * dusk Marquee / announcement strip. Two modes:
 *  • animated repeating ticker (the red "Final Days · End of Season Sale"
 *    band, or the mint rewards ribbon)
 *  • static single message (the ink delivery-notice bar)
 */
function Marquee({
  items = ['End of Season Sale'],
  tone = 'sale',
  // 'sale' | 'ink' | 'mint' | 'soft'
  animated = true,
  separator = '·',
  speed = 28,
  // seconds per loop
  emphasis,
  // optional lead word rendered bold, e.g. "Final Days"
  style,
  ...rest
}) {
  const tones = {
    sale: {
      background: 'var(--color-sale)',
      color: 'var(--dusk-white)'
    },
    ink: {
      background: 'var(--dusk-ink)',
      color: 'var(--dusk-white)'
    },
    mint: {
      background: 'var(--dusk-mint)',
      color: 'var(--dusk-ink)'
    },
    soft: {
      background: 'var(--color-bg-warm)',
      color: 'var(--dusk-ink)'
    }
  };
  const t = tones[tone] || tones.sale;
  const anim = `dusk-marquee-${Math.random().toString(36).slice(2, 8)}`;
  const Row = ({
    ariaHidden
  }) => /*#__PURE__*/React.createElement("span", {
    "aria-hidden": ariaHidden,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      paddingInline: 18
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, emphasis && /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--weight-medium)'
    }
  }, emphasis), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-light)'
    }
  }, it), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.6
    }
  }, separator))));
  if (!animated) {
    return /*#__PURE__*/React.createElement("div", _extends({
      style: {
        background: t.background,
        color: t.color,
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--weight-light)',
        fontSize: 'var(--fs-small)',
        letterSpacing: 'var(--ls-ui)',
        textAlign: 'center',
        padding: '14px 24px',
        ...style
      }
    }, rest), items.join(`  ${separator}  `));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: t.background,
      color: t.color,
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-small)',
      letterSpacing: 'var(--ls-ui)',
      padding: '14px 0',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("style", null, `@keyframes ${anim}{from{transform:translateX(0)}to{transform:translateX(-50%)}}`), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      animation: `${anim} ${speed}s linear infinite`
    }
  }, /*#__PURE__*/React.createElement(Row, null), /*#__PURE__*/React.createElement(Row, {
    ariaHidden: true
  }), /*#__PURE__*/React.createElement(Row, {
    ariaHidden: true
  }), /*#__PURE__*/React.createElement(Row, {
    ariaHidden: true
  })));
}
Object.assign(__ds_scope, { Marquee });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Marquee.jsx", error: String((e && e.message) || e) }); }

// web-flips/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "web-flips/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

__ds_ns.CategoryCard = __ds_scope.CategoryCard;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.RewardPerk = __ds_scope.RewardPerk;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.HeroBanner = __ds_scope.HeroBanner;

__ds_ns.PromoTile = __ds_scope.PromoTile;

__ds_ns.DuskLogo = __ds_scope.DuskLogo;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Header = __ds_scope.Header;

__ds_ns.Marquee = __ds_scope.Marquee;

})();
