# dusk · Design System

A working design system for **dusk** — an Australian candle & home-fragrance
retailer. It was inferred from real shipped material (the brand style guide
and ~13 weekly "web-flip" homepage builds), not from a generic e-commerce
template. Treat this as the source of truth for dusk-branded interfaces.

> **dusk in one line:** warm, affordable luxury candles & diffusers. Glossy
> coloured-glass vessels, scent-led storytelling ("Sunset Symphony", "Vanilla
> Caramel", "Bali Retreat"), a members' rewards programme, and a tagline that
> sets the tone — *made for moments · hold onto the moments that hold you.*

## What the web team actually ships
- **Web flips** — a fresh homepage hero + promo layout every week (WK40–WK52 in the source file). The `HeroBanner` + `Marquee` + tile rails are the recurring kit.
- **EDM emails** and **web redesign** work reuse the same tokens and components.

## Sources (for whoever has access)
- **Figma:** "Dusk Design System.fig" — pages: Cover, Style-Guide (Brand Color, Typography, Spacing & Logo Rules), Design-System (Icons), Component-Library, Web-Flips (WK40–WK52). The WK52 web flip is the most complete reference page.
- Icons originate from a **Heroicons** library (outline + solid, ~479 glyphs) plus four brand social marks.
- No public/production codebase was provided; everything here is extracted from the Figma file.

---

## Index / manifest

**Root**
- `styles.css` — global entry point (@import manifest only).
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`.
- `readme.md` — this guide. `SKILL.md` — portable skill manifest.

**Components** (`window.DesignSystem_a4aafe.*`)
- `components/core/` — `Button`, `IconButton`, `Badge`, `Input`
- `components/commerce/` — `ProductCard`, `CategoryCard`, `RewardPerk`
- `components/marketing/` — `HeroBanner`, `PromoTile`
- `components/navigation/` — `Header`, `Footer`, `DuskLogo`, `Marquee`
- `components/icons/` — `Icon` (name-indexed Heroicons + socials; see `Icon.d.ts`)

**UI kit**
- `ui_kits/website/` — full homepage / weekly web-flip recreation.

**Specimens** — `guidelines/*.card.html` populate the Design System tab
(Colors, Type, Spacing, Brand). Component thumbnails live next to each
component as `*.card.html`.

---

## CONTENT FUNDAMENTALS — how dusk writes

- **Voice:** warm, optimistic, intimate. dusk sells *moments and feelings*, not wax. Sensory and lifestyle-led ("Hold onto the moments that hold you").
- **Person:** speaks to *you* ("Made with **YOU** in mind", "your ultimate Candle Care guide"). Brand refers to itself as **dusk** (always lowercase, even mid-sentence).
- **Casing:** **Sentence case** for headlines and buttons ("Shop Now", "Deals of the Week", "Sign up today…"). UPPERCASE reserved for tiny eyebrows/section labels ("END OF SEASON", "SPACING SCALE", "BRIGHTEN UP YOUR EMAILS"). Scent names are Title Case ("Sunset Symphony").
- **Spelling:** Australian/British — "colour", "favourite", "personalise".
- **Promo language:** punchy and specific — "30–50% Off", "3 for 2", "Final Days", "Member Exclusive", "Last Chance", "Fan Favourite". Member price is always phrased "$17.99 **dusk Rewards**".
- **CTAs:** short, verb-first — "Shop Now", "Join Now", "Learn more".
- **Emoji:** none. The personality comes from the script tagline font (Oooh Baby) and photography, not emoji.
- **Punctuation flourish:** middot separators in metadata ("#FF585D · PANTONE 178 C"), en-dashes in ranges ("30–50%").

Example microcopy:
> *made for moments* · "Scent of the Moment: Sunset Symphony" · "Get 10% off your first order and be the first to know about new releases and sales!"

---

## VISUAL FOUNDATIONS

**Colour.** A warm, candy-warm palette anchored by **Sunset Symphony #FF585D**
(the dusk red-coral hero) over lots of white and **Soft Glow #F3ECD9** cream.
**Tokyo Temple #D22730** carries sale urgency; **Pink Icing, Ruby Rose, Vanilla
Caramel, Buttermilk Pan** are scent-storytelling support tints. Ink is a soft
near-black (#242424 body/buttons, #1A1A1A headings) — never pure black for
text. A single **amber #F7B226** powers promo badges; a **mint #B2FCE4** ribbon
flags rewards/shipping. Use brand colours from the tokens; if you need a new
shade, mix from these in oklch rather than inventing one.

**Type.** A serif-meets-sans pairing: **Shippori Mincho** (high-contrast serif)
for hero headlines and emotional copy; **Lexend** for everything UI — body,
nav, buttons, product titles, prices; **Oooh Baby** as a sparing script accent
for taglines only; **Inter** for fine print/metadata. Display serif is tracked
slightly tight (−0.02em); Lexend UI at −0.2px. Prices are set in Lexend
**Light**. (Some legacy nav used Sofia Pro → mapped to Lexend, see Iconography/fonts note.)

**Spacing & rhythm.** 4-based scale (xs4 · sm8 · md12 · lg16 · xl24 · 2xl40 ·
3xl64) with a 48px page gutter. Generous vertical breathing room between
homepage sections (~56px). Content maxes at 1440px.

**Corners — square first.** dusk is decidedly **square**: buttons, banners,
product cards, inputs and tiles all use radius 0. Rounding is reserved for
**pill** chips/badges/category-pills and a few soft swatch/spec cards
(12–24px). This squareness is a signature — don't soften it.

**Elevation.** Shadow-light. Product cards use a **1px cool hairline ring**
(`--ring-card`), not a drop shadow; icon buttons/inputs use an inset hairline.
Soft drop shadows are reserved for genuinely floating UI (dropdowns, dialogs).

**Backgrounds & imagery.** Either clean **white** or warm **Soft Glow cream**
fields — no gradients as decoration. Photography is the hero: warm, glossy
candle **still-life** and editorial flat-lays on cream seamless backdrops,
directional light, soft shadows, props echoing the scent (vanilla pods,
caramel pours). Saturated coloured-glass vessels carry the palette into the
image. Tone is always **warm** — never cool, grainy or clinical.

**Protection gradients.** Hero banners place text on photography using a
**one-sided colour wash** (e.g. solid Tokyo red fading to transparent across
the left ~55%), tinted to the week's scent story — not a translucent black
scrim and not a capsule.

**Borders.** Warm hairline `#E0D8CE` for cards/inputs; a cool `#F2F1F0` ring on
product cards; `rgba(36,36,36,.1)` dividers in header/footer.

**Motion.** Restrained and quick (~160ms ease). Marquee tickers scroll
linearly and loop. Category/product images **lift subtly on hover**
(scale ~1.04); buttons **press in** slightly (scale ~0.985) and darken; icon
buttons scale up ~1.06. No bounces, no parallax, no flashy entrances.

**Hover / press states.** Hover = subtle scale or image zoom; primary buttons
darken toward black; links underline (offset 3px). Press = slight shrink.
Disabled = 40% opacity.

---

## ICONOGRAPHY

- **System:** **Heroicons** (outline ~1.5px stroke + solid), the set used
  throughout the dusk UI (~479 glyphs in the source). Extracted into a single
  name-indexed data file at `components/icons/icon-data.js` and rendered via
  `<Icon name="…" size={…} />`. A curated, commonly-used subset is materialised
  here (search, user, heart, bag/cart, location, gift, truck, star, sparkles,
  chevrons, arrows, plus/minus/check, play, mail, globe). See
  `components/icons/Icon.d.ts` for every valid name. Need more? Re-materialise
  additional Heroicons by name, or fall back to the Heroicons CDN with the same
  stroke weight.
- **Colour:** icons paint with `currentColor` — set `color` on the element.
- **Brand socials:** Instagram, Facebook, Pinterest ("Pintrest" in source),
  TikTok marks are included in the same icon set.
- **Emoji:** not used.
- **Logo / wordmark:** ⚠ **substitution.** The official dusk wordmark is a
  custom serif lock-up. The Figma file only exposed a clean vector for the
  letter "d"; the full glyph set could not be extracted. `DuskLogo` renders
  "dusk" in the brand display serif (Shippori Mincho) as a faithful stand-in.
  **Please supply the official wordmark SVG** to replace it.
- **Fonts:** Lexend, Shippori Mincho, Oooh Baby and Inter all load from Google
  Fonts (see `tokens/fonts.css`). **Sofia Pro** (commercial, used in some
  legacy nav text) is **not** on Google Fonts and is mapped to Lexend — supply
  the licensed files if you want it restored.

---

## Using the system
Link `styles.css`, load `_ds_bundle.js`, then read components from
`window.DesignSystem_a4aafe`. Build with the tokens (CSS custom properties),
keep corners square, lead with photography, and write warm sentence-case copy.
See `SKILL.md` for the portable version.
